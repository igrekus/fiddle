def check_combination(cards:list) ->  str:
    # всего есть 4 варианта того, сколько уникальных карт(чисел) будет:
    cases = { 5: five_cards(cards),
              4: "One Pair",
              3: three_cards(cards),
              2: two_cards(cards),
              1: "Impossible"}

    # уникальных карт(чисел):
    unic_cards = set(cards)
    
    # вызываем соответсвующий кейс
    answer = cases[len(unic_cards)]

    # Ответ
    return answer
