def check_combination(cards: list) -> str:
    combinations = {11111: 'Nothing', 11122: 'One Pair', 12222: 'Two Pairs', 11333: 'Three of a Kind', 22333: 'Full House', 14444: 'Four of a Kind', 55555: 'Impossible'}
    if len(set(cards)) == 5 and sorted(cards)[4] - sorted(cards)[0] == 4:
        return 'Straight'
    return combinations[int(''.join(sorted([str(cards.count(card)) for card in cards])))]
