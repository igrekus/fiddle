def check_combination(cards: list) -> str:
    if len(cards) != 5:
        raise ValueError('Wrong list length')

    if sorted(cards) == [_ for _ in range(1, 6)]:
        return 'Straight'                   # если есть 5 последовательных ([1,2,3,4,5])
    elif len(set(cards)) == 1:
        return 'Impossible'                 # если одинаковы 5
    elif len(set(cards)) == 2:
        if set([cards.count(_) for _ in cards]) == {2, 3}:
            return 'Full House'             # если одинаковы 3 и 2 ([1,1,3,3,3])
        elif set([cards.count(_) for _ in cards]) == {1, 4}:
            return 'Four of a Kind'         # если одинаковы 4

    elif len(set(cards)) == 3:
        if set([cards.count(_) for _ in cards]) == {1, 2}:
            return 'Two Pairs'              # если одинаковы 2 и 2
        else:
            return 'Three of a Kind'        # если одинаковы 3

    elif len(set(cards)) == 4:
        return 'One Pair'                   # если одинаковы 2

    return 'Nothing'