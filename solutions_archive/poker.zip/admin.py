def check_combination(cards: list) -> str:
    uniques = {e: cards.count(e) for e in cards}
    uniques_length = len(uniques)
    cases = {'Three of a Kind': uniques_length == 3 and max(uniques.values()) == 3,
             'Four of a Kind': uniques_length == 2 and max(uniques.values()) == 4,
             'Impossible': uniques_length == 1,
             'Full House': uniques_length == 2,
             'Two Pairs': uniques_length == 3,
             'One Pair': uniques_length == 4,
             'Straight': max(cards) == min(cards) + 4,
             'Nothing': True
             }
    return [pair[0] for pair in cases.items() if pair[1]][0]