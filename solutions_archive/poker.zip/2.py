def check_combination(cards: list) -> str:
    combs_dict = {25: "Impossible", 17: "Four of a Kind",
                  11: "Three of a Kind", 7: "One Pair", 9: "Two Pairs", 13: "Full House"}
    comb = combs_dict.get(sum(cards.count(i) for i in cards))
    if not comb:
        if max(cards) - min(cards) == 4:
            return "Straight"
        else:
            return "Nothing"
    else:
        return comb