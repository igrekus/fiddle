def check_combination(cards: list) -> str:
	same = {}	
	result = {
		"" : "Nothing",
		"5" : "Impossible",
		"4" : "Four of a Kind",
		"3" : "Three of a Kind",
		"32" : "Full House",
		"23" : "Full House",
		"2" : "Pair",
		"22" : "Two Pairs",
		"Straight": ""
		}

	count = ""

	for card in cards:
		if card in same:
			same[card] += 1
			result["Straight"] += str(card)
		else:
			same[card] = 1

	for k,v in same.items():
		if v == 2:
			count += "2"
		elif v == 3:
			count += "3"
		elif v == 4:
			count += "4"
		elif v == 5:
			count += "5"

	if not count:
		if max(cards) - min(cards) == 4:
			return "Straight"
	return result[count]
