def check_combination(cards:list):
    pairs = {i:cards.count(i) for i in cards if cards.count(i) >1}
    pairs=list(pairs.values())
    if len(set(cards))==1:
        return "Impossible"
    else:
        if sorted(cards) == [*range(sorted(cards)[0],sorted(cards)[0]+5)]:
            return "Straight"
        elif pairs==[2,3] or pairs==[3,2]:
            return "Full House"
        elif pairs==[2,2]:
            return "Two Pairs"
        elif pairs==[2]:
            return "One Pair"
        elif pairs==[3]:
            return "Three of a Kind"
        elif pairs==[4]:
            return "Four of a Kind"
        else:
            return "Nothing"