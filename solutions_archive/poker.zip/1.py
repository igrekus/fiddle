# Пользователь захотел показать 2 решения и потом обсудить

def check_combination(cards: list) -> str:
    card_ = {}
    for i in cards:
        card_[i] = card_.setdefault(i,0) + 1
    
    card_len = len(card_)
    if card_len == 5:
        res = 'Straight'
        cards.sort()
        for i in range(4):
            if cards[i] == cards[i+1] - 1:
                continue
            else:
                res = 'Nothing'
                break
    elif card_len == 4:
        res = 'One Pair'
    elif card_len == 3:
        if max(card_.values()) == 3:
            res = 'Three of a Kind'
        else:
            res = 'Two Pairs'
    elif card_len == 2:
        if max(card_.values()) == 4:
            res = 'Four of a Kind'
        else:
            res = 'Full House'
    elif card_len == 1:
        res = 'Impossible'
    else:
        res = 'Err'

    return res
	
	
	
	def check_combination(cards: list) -> str:
    card_ = {}
    card_stat = dict(card_len = 0,
                max_card = 0,
                min_card = 100,
                max_card_cnt = 0)
    
    comb_dir={1:lambda card_stat: 'Impossible',
                2:lambda card_stat: 'Four of a Kind' if card_stat['max_card_cnt'] == 4 else 'Full House',
                3:lambda card_stat: 'Three of a Kind' if card_stat['max_card_cnt'] == 3 else 'Two Pairs',
                4:lambda card_stat: 'One Pair',
                5:lambda card_stat: 'Straight' if (card_stat['max_card'] - card_stat['min_card']) == 4 else 'Nothing'}
    
    for i in cards:
        if card_.setdefault(i,0):
            card_[i] += 1
            card_stat['max_card_cnt'] = card_stat['max_card_cnt'] if (card_stat['max_card_cnt'] >= card_[i]) else card_[i]
        else:
            card_stat['card_len'] += 1
            card_[i] = 1
        card_stat['max_card'] = card_stat['max_card'] if (card_stat['max_card'] >= i) else i
        card_stat['min_card'] = card_stat['min_card'] if (card_stat['min_card'] <= i) else i
    
    return comb_dir[card_stat['card_len']](card_stat)