import os
import re
import sys
import tarfile
import zipfile

contents = {}
key_phrases = []


def extract_nested_zip(zip_file, where, is_zip):
    if not os.path.exists(where):
        os.mkdir(where)

    if is_zip:
        with zipfile.ZipFile(zip_file, 'r') as zf:
            try:
                zf.extractall(path=where)
            except zipfile.BadZipFile as ex:
                print(ex)
                exit(1)

    else:
        with tarfile.open(zip_file) as tf:
            try:
                tf.extractall(path=where)
            except tarfile.TarError as ex:
                print(ex)
                exit(1)

    if '/' in where:
        os.remove(zip_file)

    for root, dirs, files in os.walk(where):
        for filename in files:
            if not re.search(r'\.txt$', filename):
                extract_nested_zip(
                    os.path.join(where, filename),
                    f"{where}/{filename.split('.')[0]}",
                    re.search(r'\.zip$', filename)
                )
            else:
                with open(os.path.join(where, filename)) as ftext:
                    contents[os.path.join(where, filename)] = ftext.readlines()
                    key_phrases.append(contents[os.path.join(where, filename)][0].strip())


if __name__ == "__main__":
    try:
        sys.argv[1]
    except IndexError:
        print("Error: The file name is required as the first argument")
    else:
        if not os.path.exists(sys.argv[1]):
            print("Error: File does not exist")
        else:
            extract_nested_zip(sys.argv[1], sys.argv[1].split('.')[0], re.search(r'\.zip$', sys.argv[1]))

            key = next((_ for _ in list(set(key_phrases)) if 'Key:' in _), None)
            if key:
                found = next(((k, v) for k, v in contents.items() if v and v[0] == f"{key}\n"), None)
                if found:
                    print(f"Placement: {found[0]}")
                    print(found[1][0])
                else:
                    print('Object by key not found')

            else:
                print('Key not found')
