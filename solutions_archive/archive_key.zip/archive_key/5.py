import zipfile, os, sys
import tarfile, glob

texts = ("Key in another file", "It's not the file you're looking for", "You're close, check another file",
         "The key is somewhere but not here", "Key is not here!", "Key in another castle!")


def do_all():
    flag = False
    for root, dirs, files in os.walk(sys.path[0], topdown=True):
        for file in glob.glob(root + "/*.tar.*"):
            folder = file.split('.')[0].split("/")[-1]
            if folder in dirs:
                continue
            with tarfile.open(file) as tar:
                flag = True
                tar.extractall(root + "/" + folder)
        for file in glob.glob(root + "/*.zip"):
            folder = file.split('.')[0].split("/")[-1]
            if folder in dirs:
                continue
            with zipfile.ZipFile(file, 'r') as zip_ref:
                flag = True
                zip_ref.extractall(root + "/" + folder)
    if flag:
        do_all()


do_all()
for root, dirs, files in os.walk(sys.path[0], topdown=True):
    for file in glob.glob(root + "/*.txt"):
        with open(file) as f:
            content = ''.join(line.rstrip() for line in f.readlines())
            has = False
            for text in texts:
                if text in content:
                    has = True
                    break
            if not has:
                print(content)