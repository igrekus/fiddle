import os
import tarfile
import zipfile
import shutil
from timeit import default_timer as timer

class File:

    def __init__(self,path,filename):
        self.filename=filename
        self.dirname=path
        self.basename=os.path.basename(filename)
        splitname=self.basename.split('.')
        self.name=splitname[0]
        self.ext='.'.join(splitname[1:])
        self.keys=list()
        # print(self.dirname,'/',self.name,'.',self.ext)
    
    def parsetxt(self):
        # print(self.dirname+'/'+self.filename,' :')
        with open(self.dirname+'/'+self.filename,'r') as f:
            with open('./result.txt','a') as fw:
                # fw.write(self.dirname+'/'+self.name+' :')
                fw.write(str(f.readline()))

    def untar(self):
        try:
            os.mkdir(self.dirname+'/'+self.name+'_'+self.ext)
        except: pass
        tar = tarfile.open(self.dirname+'/'+self.filename,"r")
        try:
            tar.extractall(self.dirname+'/'+self.name+'_'+self.ext)
        except: pass
        for tarinfo in tar:
            if tarinfo.isreg():
                file=File(self.dirname+'/'+self.name+'_'+self.ext,tarinfo.name)
                # print(self.dirname+'/'+self.name+'_'+self.ext+'/'+file.name+'.'+file.ext)
                file.unfile()
                os.remove(self.dirname+'/'+self.name+'_'+self.ext+'/'+file.name+'.'+file.ext)

    def unzip(self):
        try:
            os.mkdir(self.dirname+'/'+self.name+'_'+self.ext)
        except: pass
        zip = zipfile.ZipFile(self.dirname+'/'+self.filename,"r")
        try:
            zip.extractall(self.dirname+'/'+self.name+'_'+self.ext)
        except: pass
        for zipinfo in zip.namelist():
            file=File(self.dirname+'/'+self.name+'_'+self.ext,zipinfo)
            # print(self.dirname+'/'+self.name+'_'+self.ext+'/'+file.name+'.'+file.ext)
            file.unfile()
            os.remove(self.dirname+'/'+self.name+'_'+self.ext+'/'+file.name+'.'+file.ext)

    def unfile(self):
        if self.ext=='tar.bz2' or self.ext=='tar.gz':
            self.untar()
        elif self.ext=='zip':
            self.unzip()
        elif self.ext=='txt':
            self.parsetxt()
        else:
            pass

# Linux only
if os.name!='posix': exit()
start_time = timer()
print('Start')
file=File(".","Find_the_key.tar.bz2")
file.unfile()
dictlines={}
with open('./result.txt','r') as f:
    for line in f:
        if line in dictlines.keys():
            dictlines[line] += 1
        else:
            dictlines[line] = 1
shutil.rmtree('./Find_the_key_tar.bz2')
os.remove('./result.txt')
for key in dictlines:
     if dictlines[key]==1: print(key)
print(f'End {timer()-start_time} secs.')
# Key: <A_b1t_0f_f3st1ve_r3cUrs10n>
# End 42.41468443600024 secs.