import tarfile
import zipfile
import os

def arch_finder(path='', lstdir=os.listdir('.'), deepness=0):
    arch = ['bz2', '.gz', 'zip']
    for i in lstdir:
        if os.path.isfile(f"{path}{i}"):
            if i[-3:] in arch:
                extr(f"{path}{i}", deepness)
            elif i[-3:] == 'txt':
                freader(f"{path}{i}")
    count = 0
    while True:
        if os.listdir(f"{path if path else '.'}"):
            # print(path + lstdir[count])
            key = lstdir[count][4:lstdir[count].find('.')]
        count += 1
        if count >= len(lstdir):
            break
    for i in os.listdir(f"{path if path else '.'}"):
        if os.path.isdir(f"{path}{i}"):
            arch_finder(path=f"{path}{i}\\", lstdir=os.listdir(f"{path}{i}\\"), deepness=deepness+1)


def extr(f_name, deepness=0):
    arch = ['bz2', '.gz', 'zip']
    dir_name = f_name[:f_name.rfind('.')]
    cur_dir = os.path.dirname(f_name)
    # print(f"{dir_name}")
    if f_name[-3:] in ('tar', '.gz', 'bz2'):
        with tarfile.open(f_name) as fi:
            fi.extractall(f"{dir_name}")
    if f_name[-3:] == 'zip':
        with zipfile.ZipFile(f_name) as fi:
            fi.extractall(f"{dir_name}")

def freader(f_name):
    a = ""
    try:
        with open(f_name, 'r') as fi:
            a = fi.read()
    except:
        with open(f_name, 'r', encoding="utf-8") as fi:
            a = fi.read()
    if a.startswith("It's not the file") or\
        a.startswith("Key in another file") or\
        a.startswith("You're close, check another file") or \
        a.startswith("The key is somewhere but not here") or \
        a.startswith("Key in another castle!") or \
        a.startswith("Key is not here!"):
        pass
    else:
        print(a)


arch_finder()
