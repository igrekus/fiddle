def count_dots(radius):
        s = 0
        for k in range(1, radius + 1):
                s+=int((radius * radius - k * k) ** (1 / 2))
        return 1 + ( s + int(radius)) * 4
