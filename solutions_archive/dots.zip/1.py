def count_dots(radius: int):
    lim = radius ** 2
    counter = 0
    znamen = 1

    while lim >= znamen:
        counter += int(lim / znamen)
        counter -= int(lim / (znamen + 2))
        znamen += 4
    counter = counter * 4 + 1
    return int(counter)
