def count_dots(radius:int) -> int:
	diapason = range(-radius,radius+1)
	return(len([(x,y) for x in diapason for y in diapason if (x**2+y**2)**0.5 <= radius]))