# ты пытался
def ordinary(num):
    return str(num)


def fb(num):
    return "FizzBuzz"


def f(num):
    return "Fizz"


def b(num):
    return "Buzz"


def fizz_buzz(fizz: int, buzz: int, seq: iter) -> str:
    cases = {"11": fb, "01": b,
             "10": f, "00": ordinary}
    fizz_buzz_dict = {num:"" for num in list(seq)}
    for num in fizz_buzz_dict:
        if num % fizz == 0:   # 1 действие - проверка
            fizz_buzz_dict[num] += "1"
        else:
            fizz_buzz_dict[num] += "0"
        if num % buzz == 0:   # 2 дйствие - проверка
            fizz_buzz_dict[num] += "1"
        else:
            fizz_buzz_dict[num] += "0"
    return "\n".join([cases[fizz_buzz_dict[num]](num) for num in fizz_buzz_dict])
#                           ^ 3 действие - запрос в кеш
