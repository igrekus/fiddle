# ты очень, очень пытался
from typing import Iterable


def fizz_buzz(fizz: int, buzz: int, seq: Iterable) -> str:
    bin_fizz = int(('01' + '00' * (fizz - 1)) * buzz, 2)
    bin_buzz = int(('10' + '00' * (buzz - 1)) * fizz, 2)
    key = bin_fizz | bin_buzz   # 1 действие -- вычисление составного ключа
    _get_value = lambda x: key >> x % (fizz * buzz) * 2 & 3
    #                                                   ^ 2 действие - проверка составного ключа
    return '\n'.join([str(i + 1), 'Fizz', 'Buzz', 'FizzBuzz'][_get_value(i)] for i in (i - 1 for i in seq))
    #                                                         ^ 3 действие -- запрос значения из набора вариантов

