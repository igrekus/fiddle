# выпендрился своим паршалом а решить не смог ЛОХ
from functools import partial


def fizz_buzz(fizz=3, buzz=5, seq=None):
    return '\n'.join(map(partial(lambda lo, hi, num: {
        (True, True): 'FizzBuzz',
        (True, False): 'Fizz',
        (False, True): 'Buzz',
    }.get((num % lo == 0, num % hi == 0), str(num)), fizz, buzz), seq if seq else range(1, 16)))
    #               ^ 1 действие -- проверка
    #                              ^ 2 действие -- проверка
    #     ^ 3 действие -- запрос в кеш
