# щелбан по лбу за непрочтение ТЗ
def fizz_buzz(fizz: int, buzz: int, seq):   # seq -- последовательность, а не правая граница интервала
    result = []

    for i in seq:
        if (i == fizz) or (i % fizz == 0):   # 1 действие -- проверка
            if i == buzz or (i % buzz == 0):   # 2 действие -- проверка
                result.append('FizzBuzz')
            else:
                result.append('Fizz')
        elif i == buzz or (i % buzz == 0):   # 3 действие -- проверка
            result.append('Buzz')
        else:
            result.append(str(i))
    return ('\n').join(result)
