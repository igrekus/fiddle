# отодрать за ухо за непрочтение ТЗ
def fizz_buzz(fizz=3, buzz=5, seq=range(1, 16)) -> str:
    result = ''

    for index in seq:
        i = index
        fizzbuzz = ''

        if index % fizz == 0:   # 1 действие -- проверка
            fizzbuzz += 'Fizz'
            i = ''

        if index % buzz == 0:   # 2 действие -- проверка
            fizzbuzz += 'Buzz'
            i = ''

        result = result + str(i) + fizzbuzz + '\n'
        #                 ^               ^ 3 действие -- сборка строки из кусков (заинлайненый аккумулятор)
    return result


print(fizz_buzz())
