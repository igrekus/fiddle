# ты пытался
def fizz_buzz(fizz: int, buzz: int, seq):
    lst = []
    for i in seq:
        n = str(i)
        f = 'Fizz'
        b = 'Buzz'
        if i % 3 != 0:   # 1 действие -- проверка
            f = ''
        else:
            n = ''
        if i % 5 != 0:   # 2 действие -- проверка
            b = ''
        else:
            n = ''
        result = n + f + b   # 3 действие -- сборка строки в аккумеляторе
        lst.append(result)
    return ('\n').join(lst)
