# щелбан по носу за непрочетние ТЗ
def fizz_buzz(fizz: int, buzz: int, seq: range):
    temp = list(seq)
    out = list()
    for index, elem in enumerate(seq):
        string = ''
        if elem % fizz == 0:   # 1 действие -- проверка
            string += 'Fizz'
            temp[index] = ''
        if elem % buzz == 0:   # 2 действие -- проверка
            string += 'Buzz'
            temp[index] = ''
        out.append(str(temp[index]) + string)   # 3 действие -- сборка строки в аккумеляторе
    return '\n'.join(out)
