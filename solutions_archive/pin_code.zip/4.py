import re
import json


def text_to_pin_code(text: str) -> str:
    """
    Converts ciphertext to PIN Code

    :param text: Text with encrypted PIN code
    :return: Decrypted PIN Code
    """
    extracted_dictionary = extract_json(text)

    extracted_numbers = []
    for key, value in extracted_dictionary.items():
        if any(x.isupper() for x in key):
            extracted_numbers.extend(normalized_numbers(value))

    unique_numbers = set(extracted_numbers)
    pin_code = ''
    for number_position in range(1, 5):
        count_numbers = len([number for number in unique_numbers if len(number) == number_position])
        pin_code += str(count_numbers)

    return pin_code


def normalized_numbers(value) -> list:
    """
    Normalizes the value for decryption

    :param value: Can be str or dict
    :return: Returns a list of numbers
    """
    result = []
    if isinstance(value, str):
        normalized_value = decode_string(value)
        if normalized_value:
            result.append(normalized_value)
    elif isinstance(value, int):
        result.append(str(value))
    elif isinstance(value, list):
        for internal_value in value:
            if isinstance(internal_value, bool):  # Fix for logical type
                internal_value = int(internal_value)
            extracted_value = normalized_numbers(internal_value)
            result.extend(extracted_value)
    return result


def decode_string(string: str) -> str:
    """
    Decodes a string to a number.
    Example: from the string 'b11c2g3' we get '1123'

    :param string:
    :return:
    """
    return re.sub(r'[^\d]+', '', string)


def extract_json(text: str) -> dict:
    """
    Finds JSON in the text and loads it into the dictionary

    :param text: Text that contains JSON
    :return: Dictionary
    """
    result = None
    search_result = re.search(r'{[^\}]*}', text)
    if search_result:
        result = json.loads(search_result.group())
    return result
