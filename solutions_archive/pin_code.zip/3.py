from json import loads


def _val_to_num(field_value):
    """ Converting a field_value to a number
    """
    if isinstance(field_value, int):   # If field_value is integer
        field_dict[field_value] = ''
    elif isinstance(field_value, str):   # If field_value is string
        # Converting an alphanumeric string to numeric string
        res = ''
        for i in range(len(field_value)):
            res += field_value[i] if field_value[i].isdecimal() else ''
        try:
            field_dict[int(res)] = ''
        except ValueError:
            return
    elif isinstance(field_value, list):   # If field_value is list
        [_val_to_num(x) for x in field_value]  # Parse list


def text_to_pin_code(text: str) -> str:
    """ Convert text to pin code
    """
    global field_dict
    # Dictionary json
    field_dict = {}
    # Loading json into the dictionary json_dict
    json_dict = loads('{' + text.split('{')[1].split('}')[0] + '}')
    [_val_to_num(v) for k, v in json_dict.items() if not k.islower() and not k.isdigit()]
    # Initializing pin_list
    pin_list = [0 for _ in range(4)]
    # Check the bit depth of the value and increase the corresponding pin field
    for i in field_dict:
        res = len(str(i)) - 1
        if res < 4:
            pin_list[res] += 1 if pin_list[res] < 9 else 0
    return ''.join(map(str, pin_list))  # Return the pin code by converting it to string
