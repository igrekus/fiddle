import json
import re


def list_handler(arg: iter) -> set:
    answer = []
    for i in arg:
        if isinstance(i, list):
            answer += list_handler(i)
        else:
            answer.append("".join((filter(str.isdigit, str(i)))))
    return set(answer)


def text_to_pin_code(text: str) -> str:
    text_json = json.loads(re.search(r"{(.*)}", text).group(0))
    filtered_keys = filter(lambda x: x != x.lower(), text_json)
    correct_numbers = map(lambda x: text_json[x], filtered_keys)
    set_list = [len(i) for i in list_handler(correct_numbers)]
    return "".join([str(set_list.count(i)) if set_list.count(i) else "0" for i in range(1, 5)])
