"""
Модуль содержит методы для получения pin-кода из исходного текста
"""
import json
from string import ascii_uppercase

UPPER = set(ascii_uppercase)
NUMBERS = '1234567890'


def _process_int(value: int, agr: list) -> None:
    """
    Функция обработки значения типа int.
    Вычисялет разрядность числа и помещает его в соответсвующую ячейку агрегатора.
    Каждая ячека агрегатора хранит уникальные числа одинаковой разрядности.

    :param value: значение для обработки
    :type value: int
    :param agr: агрегатор для хранения чисел
    :type agr: list
    """
    capacity = len(str(value))
    if capacity < 5:
        agr[len(str(value)) - 1].add(value)


def _process_string(value: str, agr: list) -> None:
    """
    Функция обработки значения типа str.
    Извлекает из строки только числовые символы и приводит их к числу

    :param value: значение для обработки
    :type value: str
    :param agr: агрегатор для хранения чисел
    :type agr: list
    """
    value = ''.join([x for x in value if x in NUMBERS])
    if value:
        _process_int(int(value), agr)


def _process_list(value: list, agr: list) -> None:
    """
    Функция обработки списковых значений.
    Перебирает последовательно значения списка в соответствии с типом применяет нужный алгоритм.

    :param value: значение для обработки
    :type value: list
    :param agr: агрегатор для хранения чисел
    :type agr: list
    :raises TypeError: если тип знаения отличается от int, str, list
    """
    for val in value:
        val_type = type(val)

        if val_type is int:
            _process_int(val, agr)
        elif val_type is str:
            _process_string(val, agr)
        elif val_type is list:
            _process_list(val, agr)
        else:
            raise TypeError('Неверный тип значения внутри JSON!')


def text_to_pin_code(text: str) -> str:
    """
    Функция получения кода из исходного текста.

    :param text: исходный текст, из которого требуется получить pin-код
    :type text: str
    :return: pin код полученый в результате работы
    :rtype: str
    """
    result = [set(), set(), set(), set()]
    json_start = text.index('{')
    json_finish = text.index('}') + 1

    data = json.loads(text[json_start:json_finish])

    val_fields = (value for key, value in data.items() if set(key) & UPPER)

    _process_list(val_fields, result)

    return ''.join([str(len(x)) for x in result])
