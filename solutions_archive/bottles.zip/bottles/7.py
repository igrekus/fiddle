def song():
    full_song = []
    bottle_on_wall = 99
    suffixes = {"бутылка": [1], "бутылки": [2, 3, 4], "бутылок": [5, 6, 7, 8, 9, 0]}
    exception_suffixes = [11, 12, 13, 14]

    def create_suffix(x):
        if x in exception_suffixes:
            return "бутылок"
        for word in suffixes:
            for el in suffixes[word]:
                if el == x % 10:
                    return word

    for couplet in range(97):
        strings1 = f'{bottle_on_wall} {create_suffix(bottle_on_wall)} пива на стене, {bottle_on_wall} {create_suffix(bottle_on_wall)} пива!\n'
        bottle_on_wall -= 1
        strings2 = f'Возьми одну, передай мне, {bottle_on_wall} {create_suffix(bottle_on_wall)} пива на стене.\n\n'
        full_song.append(strings1 + strings2)
    full_song.append(
        "2 бутылки пива на стене, 2 бутылки пива!\nВозьми одну, передай мне, последняя бутылка пива на стене.\n\n")
    full_song.append(
        "Последняя бутылка пива на стене, последняя бутылка пива!\nВозьми её, передай мне, нет бутылок пива на стене.\n\n")
    full_song.append(
        "Нет бутылок пива на стене, нет бутылок пива!\nСходи в магазин, купи ещё, 99 бутылок пива на стене.")
    return ''.join(full_song)


def verses(upper: int, lower: int):
    full_song_in_list = song().split('\n\n')
    if lower == 0:
        select_couplets_in_list = full_song_in_list[-upper - 1::]
    else:
        select_couplets_in_list = full_song_in_list[-upper - 1: - lower:]
    return '\n\n'.join(select_couplets_in_list)
