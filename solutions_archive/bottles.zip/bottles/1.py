ENTIRE_COUPLET = "{0} бутыл{2} пива на стене, {1} бутыл{2} пива!\n{5} {3} бутыл{4} пива на стене."

GENERALLY = "Возьми одну, передай мне,"

LAST_WORD = "последняя"
LAST = "Возьми её, передай мне,"

EMPTY_WORD = "нет"
EMPTY = "Сходи в магазин, купи ещё,"

FULL_PACK = '99'


def suffix(n: int) -> str:
    rng = range(20, 100, 10)
    if n in [1] + [(_ + 1) for _ in rng]:
        return 'ка'
    elif n in [2, 3, 4] + [el for sublist in [[_ + 2, _ + 3, _ + 4] for _ in rng] for el in sublist]:
        return 'ки'
    else:
        return 'ок'


def couplets(lower: int = 0, upper: int = 99) -> list:
    result = []
    for i in range(lower, upper + 1):
        if i > 2:
            fmt = (i, i, suffix(i), i - 1, suffix(i - 1), GENERALLY)
        else:
            if i == 2:
                fmt = (i, i, suffix(i), LAST_WORD, suffix(i - 1), GENERALLY)
            elif i == 1:
                fmt = (LAST_WORD.title(), LAST_WORD, suffix(i), EMPTY_WORD, suffix(i - 1), LAST)
            else:
                fmt = (EMPTY_WORD.title(), EMPTY_WORD, suffix(i), FULL_PACK, suffix(i - 1), EMPTY)

        result.append(ENTIRE_COUPLET.format(*fmt))

    return result


def song() -> str:
    return '\n\n'.join(reversed(couplets()))


def verses(upper: int, lower: int) -> str:
    return '\n\n'.join(reversed(couplets(lower, upper)))


if __name__ == '__main__':
    print(verses(2, 0))
