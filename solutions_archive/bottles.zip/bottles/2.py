def bottle_generator(upper, lower):
    bottle_count = 'одну'
    new_line = '\n'
    while upper != lower-1:
        if upper == 1:
            bottle_count = 'её'
        answer = (f'{bottle_name(upper)} пива на стене, {bottle_name(upper)} пива!'.capitalize(),
                  f'Возьми {bottle_count}, передай мне, {bottle_name(upper - 1)} пива на стене.'.capitalize(),
                  f'Сходи в магазин, купи ещё, 99 бутылок пива на стене.')
        yield f'{answer[0]}\n{answer[1]}' + new_line * bool(upper-lower) if upper else f'{answer[0]}\n{answer[2]}'
        upper -= 1


def bottle_name(count):
    bottles = {
        'none': 'нет бутылок',
        'last': 'последняя бутылка',
        'one': f'{count} бутылка',
        'mul1': f'{count } бутылки',
        'mul2': f'{count} бутылок'
    }
    bottles_dict = {
        0: (bottles['none'], bottles['mul2'], bottles['mul2']),
        1: (bottles['last'], bottles['mul2'], bottles['one']),
        2: (bottles['mul1'], bottles['mul2'], bottles['mul1']),
        3: (bottles['mul2'], bottles['mul2'], bottles['mul2'])
    }
    d_factor = count // 10 if count < 20 else 2
    c_factor = count % 10 // 5 + 2 if count % 10 > 1 else count % 10
    return f'{bottles_dict[c_factor][d_factor]}'


def verses(upper: int, lower: int) -> str:
    response = [i for i in bottle_generator(upper, lower)]
    return '\n'.join(response)


def song() -> str:
    return verses(99, 0)



if __name__ == '__main__':
    print(1)
    print(verses(1,1))
    print(1)
