def verses(upper: int, lower: int) -> str:
    lyrics = []
    words = {0: "нет", 1: "последняя"}
    endings = {"1": "ка", "2": "ки", "3": "ки", "4": "ки", "последняя": "ка",
               "11": "ок", "12": "ок", "13": "ок", "14": "ок", "нет": "ок"}
    while upper >= lower:
        curr_bottle = words.get(upper, str(upper))
        next_bottle = words.get(upper - 1, str(upper - 1))
        first_ending = endings.get(curr_bottle, endings.get(curr_bottle[-1], "ок"))
        second_ending = endings.get(next_bottle, endings.get(next_bottle[-1], "ок"))
        verse = f"{curr_bottle.title()} бутыл{first_ending} пива на стене, {curr_bottle} бутыл{first_ending} пива!\n"
        if upper == 0:
            verse += "Сходи в магазин, купи ещё, 99 бутылок пива на стене."
        else:
            curr_bottle = "её" if upper == 1 else "одну"
            verse += f"Возьми {curr_bottle}, передай мне, {next_bottle} бутыл{second_ending} пива на стене."
        upper -= 1
        lyrics.append(verse)
    return "\n\n".join(lyrics)


def song() -> str:
    return verses(99, 0)
