def song() -> str:
    return verses(99, 0)


def get_name(value: int) -> str:
    if value == 0:
        return 'нет бутылок'
    if value == 1:
        return 'последняя бутылка'
    if value < 0:
        value = 99
    if value in range(11, 20) or str(value)[-1] in '056789':
        return f'{value} бутылок'
    if value in range(21, 101, 10):
        return f'{value} бутылка'
    return f'{value} бутылки'


def _get_prefix(value: int) -> str:
    if value == 1:
        return "Возьми её, передай мне"
    elif value == 0:
        return 'Сходи в магазин, купи ещё'
    return 'Возьми одну, передай мне'


def verses(upper: int, lower: int) -> str:
    template = lambda a, b: f'{get_name(a).capitalize()} пива на стене, {get_name(a)} пива!\n' \
                            f'{b}, {get_name(a - 1)} пива на стене.'
    result = [template(x, _get_prefix(x)) for x in reversed(range(lower, upper + 1))]
    return '\n\n'.join(result)
