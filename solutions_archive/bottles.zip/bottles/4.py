import functools
from typing import Generator


def __word_ending(numeral, endings: tuple):
    """
    Decline nouns after numerals

    :param numeral: Number
    :param endings: Tuple with word ending for 1, 4 and other numbers
    :return: Word ending based on number
    """
    if len(endings) != 3:
        raise ValueError('Exactly 3 values are expected in variable "endings"')

    numeral = numeral % 100
    if 11 <= numeral <= 19:
        return endings[2]
    num = numeral % 10
    if num == 1:
        return endings[0]
    elif 2 <= num <= 4:
        return endings[1]
    return endings[2]


@functools.lru_cache(None)
def __bottle_text(number):
    """
    Returns the correct form of the text "N бутылок"

    :param number: Number of bottles
    :return: The correct form of the text "N бутылок". Example: "1 бутылка", "2 бутылки", "98 бутылок"
    """
    return f"{number} бутыл{__word_ending(number, ('ка', 'ки', 'ок'))}"


def __couplet_generator(upper: int, lower: int) -> Generator[str, None, None]:
    """
    Generates couplets for the song "N бутылок пива на стене!"

    :param upper: The number to start generate bottles couplets
    :param lower: The number at which you want to stop the bottle couplets generating
    :return: Generator with couplets
    """
    couplet_template = '{bottle} пива на стене, {bottle} пива!\nВозьми одну, передай мне, {next_bottle} пива на стене.'
    end_couplets = (
        'Нет бутылок пива на стене, нет бутылок пива!\nСходи в магазин, купи ещё, 99 бутылок пива на стене.',
        'Последняя бутылка пива на стене, последняя бутылка пива!\nВозьми её, передай мне, нет бутылок пива на стене.',
        '2 бутылки пива на стене, 2 бутылки пива!\nВозьми одну, передай мне, последняя бутылка пива на стене.',
    )
    end_couplets_len = len(end_couplets)
    for bottle_num in range(upper, lower - 1, -1):
        if bottle_num < end_couplets_len:
            yield end_couplets[bottle_num]
        else:
            yield couplet_template.format(bottle=__bottle_text(bottle_num), next_bottle=__bottle_text(bottle_num - 1))


def verses(upper: int, lower: int) -> str:
    """
    Returns couplets from upper to lower bottles

    :param upper: The number to start counting bottles
    :param lower: The number at which you want to stop the bottle counting
    :return: Couplets
    """
    if upper < lower:
        raise ValueError('the "upper" variable is less than the "lower" variable.')
    if lower < 0:
        raise ValueError('the `lower` variable must be greater than zero')

    return '\n\n'.join(__couplet_generator(upper, lower))


def song() -> str:
    """
    Returns the text of the fun song "99 Bottles"

    :return: Lyrics
    """
    return verses(99, 0)

