import string

LETTERS = list(string.ascii_uppercase)


def diamond(letter: str, background: str = ' ') -> str:
    used_letters = LETTERS[:LETTERS.index(letter.upper()) + 1]
    rhomb_size = len(used_letters) * 2 - 1
    rhomb = [[" "] * rhomb_size for _ in range(rhomb_size)]
    central_index = rhomb_size // 2

    for i in range(len(used_letters)):
        rhomb[i][central_index - LETTERS.index(used_letters[i])] = used_letters[i]
        rhomb[i][central_index + LETTERS.index(used_letters[i])] = used_letters[i]

    for i, line in enumerate(rhomb[:central_index]):
        rhomb[-(i + 1)] = line

    res = ""
    for i in range(len(rhomb)):
        res += "".join(rhomb[i]) + "\n"

    return res.replace(" ", background)
