import string


def diamond(letter: str, background: str = ' '):
    a_z = string.ascii_uppercase

    num = int()
    for sym in range(len(a_z)):
        if letter == a_z[sym]:
            num = sym
    num += 1

    right_part = a_z[:num]

    first_and_last_slice = (background * (num - 1) + right_part[0] + background * (num - 1)) + '\n'

    list_with_slices = []
    if letter != 'A':
        for i in range(1, num):
            slice = (background * (num - 1 - i) + right_part[i] + background * (i - 1) + background + background * (
                    i - 1) + right_part[i] + background * (num - 1 - i))
            list_with_slices.append(slice)

        return_string = ''
        return_string += first_and_last_slice
        for sl in list_with_slices:
            return_string += (sl + '\n')

        list_with_slices.pop(-1)

        for i in range(1, len(list_with_slices) + 1):
            j = -i
            return_string += (list_with_slices[j] + '\n')
        return_string += first_and_last_slice

        return return_string
    else:
        return first_and_last_slice
