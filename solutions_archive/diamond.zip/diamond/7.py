def diamond(letter: str, background: str=' ') -> str:
    """Creates an ASCII-styled diamond with ascending letters on its edges"""
    length = (ord(letter) - ord('A')) * 2 + 1
    picture = [[background for j in range(length)] for i in range(length)]
    for row_index in range(length):
        for column_index in range(length):
            offset = abs(ord('A') - ord(letter) + row_index)
            current_symbol = chr(ord(letter) - offset)
            if column_index == offset or column_index == length - 1 - offset:
                picture[row_index][column_index] = current_symbol
    return '\n'.join(map(''.join, picture)) + '\n'
