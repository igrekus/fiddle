import string

import numpy as np


def diamond(letter: str, background: str = ' ') -> str:
    m_size = string.ascii_uppercase.index(letter.upper()) + 1
    proto_matrix = [
        [(lambda i, j: string.ascii_uppercase[i] if i == j else background)(i, j) for j in range(m_size)]
        for i in range(m_size)
    ]
    result = np.lib.pad(proto_matrix, ((0, m_size - 1), (m_size - 1, 0)), 'reflect')
    return '\n'.join(''.join(cell for cell in row) for row in result) + '\n'
