def diamond(letter: str, background: str = ' '):
    ALPHABET = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U",
                "V", "W", "X", "Y", "Z"]
    width = ALPHABET.index(letter)
    back_counter = width
    delta = 1
    start_end_string = background * width + "A" + background * back_counter + "\n"
    up_half = ""
    for i in range(1, width + 1):
        back_counter -= 1
        up_half += background * back_counter + ALPHABET[i] + background * delta + ALPHABET[
            i] + background * back_counter + "\n"
        delta += 2
    down_half = "\n".join(up_half.rstrip().split("\n")[:-1][::-1])
    if width == 0:
        return "A" + "\n"
    elif width == 1:
        return start_end_string + up_half + down_half + start_end_string
    return start_end_string + up_half + down_half + "\n" + start_end_string


if __name__ == '__main__':
    print(f'-{diamond("B")}-')
