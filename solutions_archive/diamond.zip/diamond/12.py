import string


def diamond(letter: str, background: str = ' '):
    position = string.ascii_uppercase.index(letter)
    back_list = ['A']
    back_list = [[background for i in range(position * 2 + 1)] for j in range(position + 1)]
    for index in range(len(back_list)):
        back_list[index][position - index] = string.ascii_uppercase[index]
        back_list[index][-(position - index) - 1] = string.ascii_uppercase[index]
    back_list.extend(list(reversed(back_list))[1:])
    return '\n'.join(''.join(_) for _ in back_list) + '\n'


if __name__ == '__main__':
    print(diamond('C', '-'))
