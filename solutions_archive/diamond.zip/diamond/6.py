def diamond(letter: str, background: str = ' ') -> str:
    return '\n'.join([''.join([chr(ord(letter) - abs(ord('A') - ord(letter) + row_index)) if i == abs(
        ord('A') - ord(letter) + row_index) or i == (ord(letter) - ord('A')) * 2 - abs(
        ord('A') - ord(letter) + row_index) else background for i in range((ord(letter) - ord('A')) * 2 + 1)]) for
                      row_index in range((ord(letter) - ord('A')) * 2 + 1)]) + '\n'
