string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
letters = list(string)

def diamond(letter: str, background: str=''):
    if letter == 'A':
        return 'A\n'
    else:
        output = ''
        background = background if background else ' '
        index = letters.index(letter)
        output += (('{0:'+background+'^'+str(index*2+1)+'}\n').format('A'))
        for i in letters[1:index+1]:
            output += (('{0:'+background+'^'+str(index*2+1)+'}\n').format(i + (letters.index(i)*2-1)*background + i))
        number = letters[1:index]
        number = sorted(number, reverse=True)
        for i in number:
            output += (('{0:'+background+'^'+str(index*2+1)+'}\n').format(i + (letters.index(i)*2-1)*background + i))
        output += (('{0:'+background+'^'+str(index*2+1)+'}\n').format('A'))
        return output
