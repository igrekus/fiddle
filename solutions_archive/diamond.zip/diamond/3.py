def diamond(letter: str, background: str = ' ') -> str:
    if ord(letter) - 65 == 0:
        return letter + "\n"
    result = []
    start_symbol_ord = 65
    quantity_bg_side = ord(letter) - 65
    result.append(background * quantity_bg_side + chr(start_symbol_ord) +
                  background * quantity_bg_side)
    quantity_between = 1
    start_symbol_ord += 1
    quantity_bg_side -= 1
    while start_symbol_ord <= ord(letter):
        result.append(background * quantity_bg_side +
                      chr(start_symbol_ord) +
                      quantity_between * background +
                      chr(start_symbol_ord) +
                      background * quantity_bg_side)

        quantity_between += 2
        quantity_bg_side -= 1
        start_symbol_ord += 1
    result += result[-2::-1]
    return "\n".join(result) + "\n"
