def to_russian_string(value: int) -> str:
    if value < 0 or value > 999:
        raise ValueError("to_russian_string must take a value between 0 and 999")
    numdict={"1":"сто", "2":"двести", "3":"триста","4":"четыреста","5":"пятьсот","6":"шестьсот","7":"семьсот","8":"восемьсот","9":"девятьсот"}
    numdict2={"10":"десять","11":"одиннадцать","12":"двенадцать","13":"тринадцать","14":"четырнадцать","15":"пятнадцать","16":"шестнадцать","17":"семнадцать","18":"восемнадцать","19":"девятнадцать"}
    numdict3={"2":"двадцать","3":"тридцать","4":"сорок","5":"пятьдесят","6":"шестьдесят","7":"семьдесят","8":"восемьдесят","9":"девяносто"}
    numdict4={"1":"один","2":"два","3":"три","4":"четыре","5":"пять","6":"шесть","7":"семь","8":"восемь","9":"девять"}
    ret=""
    val=str(value)
 
    if len(val)==3:
        ret+= numdict[val[0]]+" "
    if len(val)>1:
        if numdict2.get(val[-2:]):
            ret+=numdict2.get(val[-2:])+" "
        else:
            if numdict3.get(val[-2]):
                ret+=numdict3.get(val[-2])+" "
            if numdict4.get(val[-1]):
                ret+=numdict4.get(val[-1])
    if len(val)==1:
        if val=="0":
            return "ноль"
        else:
            ret+=numdict4.get(val[0])
    return ret.strip()
