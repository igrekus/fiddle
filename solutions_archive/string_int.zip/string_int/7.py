NUMS = {
    '0': ('', ''),
    '1': ('сто', ''),
    '2': ('двести', 'двадцать'),
    '3': ('триста', 'тридцать'),
    '4': ('четыреста', 'сорок'),
    '5': ('пятьсот', 'пятьдесят'),
    '6': ('шестьсот', 'шестьдесят'),
    '7': ('семьсот', 'семьдесят'),
    '8': ('восемьсот', 'восемьдесят'),
    '9': ('девятьсот', 'девяносто'),
}

SIMPLE = ['ноль', 'один', 'два', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять']
DECIMAL = [
    'десять',
    'одиннадцать',
    'двенадцать',
    'тринадцать',
    'четырнадцать',
    'пятнадцать',
    'шестнадцать',
    'семнадцать',
    'восемнадцать',
    'девятнадцать',
]


def to_russian_string(value: int) -> str:

    if not(0 <= value <= 999):
        raise ValueError('Значение находиться за пределами допустимого диапазона!')

    *value, char = str(value)

    if not value:
        return SIMPLE[int(char)]
    elif value[-1] == '1':
        result = [DECIMAL[int(char)]]
    else:
        result = [SIMPLE[int(char)]] if char != '0' else []

    for ind, char in enumerate(reversed(value), 1):
        if val := NUMS[char][-(ind)]:
            result.insert(0, val)

    return ' '.join(result)

print(to_russian_string(200))