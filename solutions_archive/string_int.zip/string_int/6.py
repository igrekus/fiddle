def to_russian_string(value: int) -> str:
    """
    Converts a number to a string representation

    :param value: Number between 0 and 999.
    :return: String representation for value.
    """
    if not isinstance(value, int) or (value < 0 or value > 999):
        raise ValueError('The value must be a number from 0 to 999')

    from0_to_19 = {
        '1': 'один', '2': 'два', '3': 'три', '4': 'четыре', '5': 'пять', '6': 'шесть', '7': 'семь',
        '8': 'восемь', '9': 'девять', '10': 'десять', '11': 'одиннадцать', '12': 'двенадцать',
        '13': 'тринадцать', '14': 'четырнадцать', '15': 'пятнадцать', '16': 'шестнадцать',
        '17': 'семнадцать', '18': 'восемнадцать', '19': 'девятнадцать',
    }
    if value < 10:
        from0_to_19['0'] = 'ноль'

    tens = {
        '1': 'десять', '2': 'двадцать', '3': 'тридцать', '4': 'сорок', '5': 'пятьдесят', '6': 'шестьдесят',
        '7': 'семьдесят', '8': 'восемьдесят', '9': 'девяносто',
    }

    hundreds = {
        '1': 'сто', '2': 'двести', '3': 'триста', '4': 'четыреста', '5': 'пятьсот', '6': 'шестьсот',
        '7': 'семьсот', '8': 'восемьсот', '9': 'девятьсот',
    }
    representation_map = {
        1: from0_to_19,
        2: tens,
        3: hundreds,
    }
    str_value = str(value)
    result_list = []
    while len(str_value) != 0:
        first_number = str_value[0]
        len_value = len(str_value)
        if len_value in representation_map:
            current_map = representation_map[len_value]
            if len_value == 2 and str_value in from0_to_19:
                result_list.append(from0_to_19[str_value])
                break
            elif first_number in current_map:
                result_list.append(current_map[first_number])
            str_value = str_value[1:]
    return ' '.join(result_list)
