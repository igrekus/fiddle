def to_russian_string(value: int) -> str:
	if not 0 <= value <= 999:
		raise Exception('Вне диапазона  "от 0 до 999 включительно"')
	value = str(value)
	result = ""

	nums = {
		"0" : "ноль", "1" : "один", "2" : "два", "3" : "три", "4" : "четыре",
		"5" : "пять", "6" : "шесть", "7" : "семь", "8" : "восемь", "9" : "девять", "10" : "десять"
	}
	ranks = [i for i in range(len(value))]

	if value in nums:
		return nums[value]

	ranks[0] = f"{nums[value[-1]]}" if value[-1] != '0' else ""

	if value[-2] == '1':
		last = nums[value[-1]][-1]
		if last == "ь" or last == "е":
			last = ""
		elif last == "а":
			last = "е"

		ranks[0] = ''
		if value[-1] != "0":
			ranks[1] =  f"{nums[value[-1]][:-1]}{last}надцать"
		else:
			ranks[1] = f"десять"

	elif value[-2] == "0":
		ranks[1] = ''

	elif value[-2] == "4":
		ranks[1] = "сорок"

	elif value[-2] == '9':
		ranks[1] = "девяносто"

	elif int(value[-2]) < 4:
		ranks[1] = f"{nums[value[-2]]}дцать"

	elif int(value[-2]) > 4 :
		ranks[1] = f"{nums[value[-2]]}десят"

	if len(value) > 2:
		if value[-3] == "1":
			ranks[2] = f"сто"
		elif value[-3] == "2":
			ranks[2] = f"двести"
		elif 5 > int(value[-3]) > 2:
			ranks[2] = f"{nums[value[-3]]}ста"
		elif int(value[-3]) > 4:
			ranks[2] = f"{nums[value[-3]]}сот"
	
	ranks = ranks[::-1]
	for i in range(len(ranks)):
		if i == len(ranks)-1:
			result += ranks[i]
		elif ranks[i] == "":
			pass
		else:
			result += ranks[i] + " "
	return result.rstrip()
