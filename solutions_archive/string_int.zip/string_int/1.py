def to_russian_string(value: int) -> str:
    if value < 0 or value > 999:
        raise ValueError('Only positive ints allowed [1:1000)')
    prime = ('ноль', 'один', 'два', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять')
    tenth = {'10': 'десять', '11': 'одиннадцать', '12': 'двенадцать', '13': 'тринадцать'}
    two_digits = {'2': 'двадцать', '3': 'тридцать', '4': 'сорок', '9': 'девяносто'}
    hundreds = {'1': 'сто', '2': 'двести', '3': 'триста', '4': 'четыреста'}
    if value < 10:
        return prime[value]
    str_value = str(value)
    if value < 20:
        return tenth.get(str_value) if str_value in tenth else f'{prime[int(str_value[-1])][:-1]}надцать'
    first = str_value[0]
    last = str_value[-1]
    if value < 100:
        first_part = two_digits.get(first) if first in two_digits else f'{prime[int(first)]}десят'
        return first_part if last == '0' else f'{first_part} {to_russian_string(int(str_value[1:]))}'
    first_part = hundreds.get(first) if first in hundreds else f'{prime[int(first)]}сот'
    return first_part if str_value[1:] == '00' else f'{first_part} {to_russian_string(int(str_value[1:]))}'