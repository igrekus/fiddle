def to_russian_string(value: int) -> str:
    """
    Новый вызов для смелых, ловких и умелых! Правила те же: сигнатуру не менять, импортировать только из стандартной бибилиотеки, решения слать мне в личку,
    предварительно внимательно проверив и убедившись что все по ТЗ. Не жалейте тестов!
    Реализовать функцию to_russian_string(value: int) -> str:, которая примнимает на вход целое число от 0 до 999 (включая) и
    возвращает его письменное преставление на русском языке строчными буквами, например 0='ноль', 111='сто одиннадцать'. Только 1 пробел между словами!
    При неверных значениях бросать любое адекватное исключение. Кто не силен в русском, советую проверять по гуглу как пишутся те или
    иные числительные, чтобы потом не удивляться.#task
    """

    def get_digits0(s1: int) -> str:
        digits = ("", "один", "два", "три", "четыре", "пять", "шесть", "семь", "восемь", "девять")
        return digits[s1]

    def get_digits11(s1: int) -> str:
        digits = ("", "одиннадцать", "двенадцать", "тринадцать", "четырнадцать", "пятнадцать", "шестнадцать", "семнадцать", "восемнадцать", "девятнадцать")
        return digits[s1]

    def get_digits20(s2: int, s1: int) -> str:
        digits = ("", "десять", "двадцать", "тридцать", "сорок", "пятьдесят", "шестьдесят", "семьдесят", "восемьдесят", "девяносто")
        if s2 == 0:
            return get_digits0(s1)
        if s1 == 0:
            return digits[s2]
        if s2 == 1:
            return get_digits11(s1)
        return digits[s2] + " " + get_digits0(s1)

    def get_digits100(s3: int, s2: int, s1: int) -> str:
        digits = ("", "сто", "двести", "триста", "четыреста", "пятьсот", "шестьсот", "семьсот", "восемьсот", "девятьсот")
        if s3 == 0:
            if s2 == 0 and s1 == 0:
                return "ноль"
            return get_digits20(s2, s1)
        if s2 == 0 and s1 == 0:
            return digits[s3]
        return digits[s3] + " " + get_digits20(s2, s1)

    s3 = value

    if 0 <= s3 <= 999:  # 925
        s2 = s3 % 100  # 25
        s1 = s2 % 10  # 5
        return get_digits100((s3 - s2) // 100, (s2 - s1) // 10, s1)

    raise ValueError("value must be in range 0 - 999")


values1 = (0, 1, 9, 10, 11, 19, 20, 21, 29, 90, 91, 100, 101, 111, 120, 121, 925, 1000, -1)


def test_to_russian_string_0():
    str = to_russian_string(values1[0])
    assert len(str) > 0
    assert str.count(" ") == 0
    assert str == "ноль"


def test_to_russian_string_1():
    str = to_russian_string(values1[1])
    assert len(str) > 0
    assert str.count(" ") == 0
    assert str == "один"


def test_to_russian_string_2():
    str = to_russian_string(values1[2])
    assert len(str) > 0
    assert str.count(" ") == 0
    assert str == "девять"


def test_to_russian_string_3():
    str = to_russian_string(values1[3])
    assert len(str) > 0
    assert str.count(" ") == 0
    assert str == "десять"


def test_to_russian_string_4():
    str = to_russian_string(values1[4])
    assert len(str) > 0
    assert str.count(" ") == 0
    assert str == "одиннадцать"


def test_to_russian_string_5():
    str = to_russian_string(values1[5])
    assert len(str) > 0
    assert str.count(" ") == 0
    assert str == "девятнадцать"


def test_to_russian_string_6():
    str = to_russian_string(values1[6])
    assert len(str) > 0
    assert str.count(" ") == 0
    assert str == "двадцать"


def test_to_russian_string_7():
    str = to_russian_string(values1[7])
    assert len(str) > 0
    assert str.count(" ") == 1
    assert str == "двадцать один"


def test_to_russian_string_8():
    str = to_russian_string(values1[8])
    assert len(str) > 0
    assert str.count(" ") == 1
    assert str == "двадцать девять"


def test_to_russian_string_9():
    str = to_russian_string(values1[9])
    assert len(str) > 0
    assert str.count(" ") == 0
    assert str == "девяносто"


def test_to_russian_string_10():
    str = to_russian_string(values1[10])
    assert len(str) > 0
    assert str.count(" ") == 1
    assert str == "девяносто один"


def test_to_russian_string_11():
    str = to_russian_string(values1[11])
    assert len(str) > 0
    assert str.count(" ") == 0
    assert str == "сто"


def test_to_russian_string_12():
    str = to_russian_string(values1[12])
    assert len(str) > 0
    assert str.count(" ") == 1
    assert str == "сто один"


def test_to_russian_string_13():
    str = to_russian_string(values1[13])
    assert len(str) > 0
    assert str.count(" ") == 1
    assert str == "сто одиннадцать"


def test_to_russian_string_14():
    str = to_russian_string(values1[14])
    assert len(str) > 0
    assert str.count(" ") == 1
    assert str == "сто двадцать"


def test_to_russian_string_15():
    str = to_russian_string(values1[15])
    assert len(str) > 0
    assert str.count(" ") == 2
    assert str == "сто двадцать один"


def test_to_russian_string_16():
    str = to_russian_string(values1[16])
    assert len(str) > 0
    assert str.count(" ") == 2
    assert str == "девятьсот двадцать пять"


def test_to_russian_string_17():
    fail = False
    try:
        str = to_russian_string(values1[17])
    except ValueError:
        fail = True
    assert fail


def test_to_russian_string_18():
    fail = False
    try:
        str = to_russian_string(values1[18])
    except ValueError:
        fail = True
    assert fail
