
def to_russian_string(value):
    data = str(value)
    if len(data) > 3 or value < 0:
        raise Exception("Wrong numbers")
    
    numbers_list = []
    result_str = ""

    dozens = {"0":"", "1":"десять", "2":"двадцать", "3":"тридцать", "4":"сорок", "5":"пятьдесят", "6":"шестьдесят", "7":"семьдесят", "8":"восемьдесят", "9":"девяносто"}
    teens = {"0":"десять", "1":"одиннадцать", "2":"двенадцать", "3":"тринадцать", "4":"четырнадцать", "5":"пятнадцать", "6":"шестнадцать", "7":"семнадцать", "8":"восемнадцать", "9":"девятнадцать"}
    hundreds ={"1":"сто", "2":"двести", "3":"триста", "4":"четыреста", "5":"пятьсот", "6":"шестьсот", "7":"семьсот", "8":"восемьсот", "9":"девятьсот"}
    numbers ={"0":"ноль", "1":"один", "2":"два", "3":"три", "4":"четыре", "5":"пять", "6":"шесть", "7":"семь", "8":"восемь", "9":"девять"}

    if len(data) == 2 and data[0] == "1":
        numbers_list.append(teens.get(data[1]))
        result_str = " ".join(numbers_list)

    elif len(data) == 2 and data[0] != "1":
        if data[1] == "0":
            numbers_list.append(dozens.get(data[0]))
            result_str = " ".join(numbers_list)
        else:
            numbers_list.append(dozens.get(data[0]))
            numbers_list.append(numbers.get(data[0+1]))
            result_str = " ".join(numbers_list)
        
    elif len(data) == 3:
        if data[1] == "0" and data[2] == "0":
            numbers_list.append(hundreds.get(data[0]))
            result_str = " ".join(numbers_list)
        elif data[1] == "1":
            numbers_list.append(hundreds.get(data[0]))
            numbers_list.append(teens.get(data[2]))
            result_str = " ".join(numbers_list)
        elif data[2] == "0":
            numbers_list.append(hundreds.get(data[0]))
            numbers_list.append(dozens.get(data[1]))
            result_str = " ".join(numbers_list)
        else:
            numbers_list.append(hundreds.get(data[0]))
            if data[1] != 0:
                numbers_list.append(dozens.get(data[0+1]))
            numbers_list.append(numbers.get(data[0+2]))
            result_str = " ".join(numbers_list)
            result_str = result_str.replace("  ", " ")

    elif len(data) == 1:
        numbers_list.append(numbers.get(data[0]))
        result_str = " ".join(numbers_list)

    return result_str
