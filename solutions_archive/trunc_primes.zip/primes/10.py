def is_prime(num):
    if num <= 3:
        return num > 1
    elif num % 2 == 0 or num % 3 == 0:
        return False
    i = 5
    while i * i <= num:
        if num % i == 0 or num % (i + 2) == 0:
            return False
        i = i + 6
    return True

def correct(num, i = 1):
    num = str(num)
    length = len(num)
    while i < length:
        num1 = num[0:length - i]
        num2 = num[i:]
        if is_prime(int(num1)) == False or is_prime(int(num2)) == False:
            return False
        i = i + 1
    return True

def generate():
    item,n = 8,11
    lst = []
    while n > 0:
        if is_prime(item) and correct(item):
            n = n - 1
            lst.append(item)
        item = item + 1
    return lst
