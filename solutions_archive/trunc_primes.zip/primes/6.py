from typing import Iterator


def generate_primes(maximum: int) -> Iterator:
    """Generates prime number using Eratosthenes sieve algorithm"""
    primes = [False] * maximum
    yield 2
    for possible_prime in range(3, maximum, 2):
        if primes[possible_prime]:
            continue
        yield possible_prime
        if possible_prime ** 2 > maximum:
            continue
        for composite_number in range(possible_prime, maximum, possible_prime):
            primes[composite_number] = True


def truncate_number(number: int) -> Iterator:
    """Generates left- and right-truncated numbers"""
    current_length = 1
    while current_length < len(str(number)):
        yield number // 10 ** current_length
        yield number % 10 ** (len(str(number)) - current_length)
        current_length += 1


def generate() -> list:
    """Creates a list with both left and right truncatable prime numbers"""
    truncatable_primes = []
    all_primes = set()
    primes_generator = generate_primes(10 ** 6)
    while True:
        current_prime = next(primes_generator)
        all_primes.add(current_prime)
        truncated_numbers = set(truncate_number(current_prime))
        if truncated_numbers.issubset(all_primes):
            truncatable_primes.append(current_prime)
        if len(truncatable_primes) > 14:
            break
    return truncatable_primes[4:]


if __name__ == '__main__':
    print(list(generate_primes(10000)))