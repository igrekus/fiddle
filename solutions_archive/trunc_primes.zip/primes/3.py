def is_prime(p):
    if p in {2, 3, 5, 7}:
        return True

    if p < 2 or not all([p % 2, p % 3, p % 5]):
        return False

    f = 5
    while int(p ** 0.5) > f:
        if not p % f or not p % (f + 2):
            return False

        f += 6

    return True


def g(p):
    yield p
    str_p = str(p)
    for i in range(1, len(str_p)):
        yield int(str_p[:-i])
        yield int(str_p[i:])


def generate() -> list:
    ret = []
    i = 11
    while 1:
        if all(map(is_prime, g(i))):
            ret.append(i)
            if len(ret) == 11:
                break

        i += 2

    return ret


if __name__ == '__main__':
    # import time
    # start = time.process_time()
    result = generate()
    # end = time.process_time()
    # print(result, 'total runtime: ' + str(end - start), sep='\n')
