from itertools import chain


def generate_right_truncatable_primes() -> list:
    possible_right_symbols = (1, 3, 7, 9)
    add_right_symbol = lambda x: [x * 10 + symbol for symbol in possible_right_symbols]
    current_list = [2, 3, 5, 7]
    result_list = []
    while True:
        result_list.extend(current_list)
        current_list = list(filter(is_prime, chain(*[add_right_symbol(_) for _ in current_list])))
        if not current_list:
            break
    return result_list


def is_prime(number: int) -> bool:
    if number == 1:
        return False
    for divisor in range(3, int(number ** 0.5) + 1, 2):
        if number % divisor == 0:
            return False
    return True


def is_left_truncatable(number: int) -> bool:
    while number:
        if not is_prime(number):
            return False
        truncate_left = lambda x: x % 10 ** (len(str(x)) - 1)
        number = truncate_left(number)
    return True


def generate() -> list:
    return list(filter(is_left_truncatable, generate_right_truncatable_primes()))[4:]
