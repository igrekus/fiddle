def find_primary():
    n = 800000
    a = [i for i in range(n + 1)]
    a[1] = 0
    lst = []
    i = 2
    while i <= n:
        if a[i] != 0:
            lst.append(a[i])
            for j in range(i, n + 1, i):
                a[j] = 0
        i += 1
    return lst


def left(number):
    number = str(number)
    if len(number) == 1:
        pass
    else:
        result.append(int(number[1:]))
        left(number[1:])
    return result


def right(number):
    number = str(number)
    if len(number) == 1:
        pass
    else:
        result.append(int(number[:-1]))
        right(number[:-1])
    return result


def generate():
    total_result = []
    primaries = find_primary()
    primaries[3999] = 739397
    for primary in primaries[4:4000]:
        global result
        result = []
        left(primary)
        right(primary)
        if set(result).issubset(primaries):
            total_result.append(primary)
    return total_result
