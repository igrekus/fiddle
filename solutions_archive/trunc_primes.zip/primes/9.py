def is_tricky_prime(prime: str):
    if len(prime) > 2:
        if "0" in prime or "2" in prime or "4" in prime or "6" in prime or "8" in prime:
            return False
    for b in range(1, len(prime)):
        if int(prime[b:]) in primes:
            pass
        else:
            return False
        if int(prime[:-b]) in primes:
            pass
        else:
            return False
    return True


def generate() -> list:
    tricky_primes = []
    for prime in primes[5:]:
        if is_tricky_prime(str(prime)):
            tricky_primes.append(prime)
    return tricky_primes


num = 1_000_000
a = list(range(num + 1))
a[1] = 0
primes = []
i = 2
while i <= num:
    if a[i] != 0:
        primes.append(a[i])
        for j in range(i, num + 1, i):
            a[j] = 0
    i += 1

