def is_prime(n: int) -> bool:
    if n == 2:
        return True
    if n % 2 == 0 or n < 2:
        return False
    i = 3
    while i ** 2 <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def is_partially_prime(value: int) -> bool:
    if not is_prime(value):
        return False
    str_value = str(value)
    parts = {str_value[:i] for i in range(1, len(str_value))}
    parts.update({str_value[-i:] for i in range(1, len(str_value))})
    for e in parts:
        if not is_prime(int(e)):
            return False
    return True


def generate() -> list:
    generator_ = (e for e in range(8, 740_000) if is_partially_prime(e))
    return [next(generator_) for _ in range(11)]

# #task Число 3137 - простое, но кроме того оно обладает интересным свойством: если слева убирать из него по 1 цифре, оставшееся число все равно будет простым
# то есть 3137-137-37-7, более того если убирать по 1 цифре справа, то опять же остаток всегда будет простым, то есть 3137-313-31-3. Написать функцию
# `def generate()->list` которая вернет список из 11 первых чисел больших 7 (включая 3137), которые обладают тем же свойством.
# Функция только возвращает результат, ничего не печатает в консоль, решения слать мне в личку модулем питона, можно импортировать из стандарта.
# Особенный респект тому, кто сделает наиболее быстрое решение.
#
#
