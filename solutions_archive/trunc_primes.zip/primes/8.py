def is_it_simple_number(num: int) -> bool:
    """
    Эта функция принимает на вход число и определяет, простое это число, или нет. Соответственно возвращает результат:
    True, если простое; Falsе, если не простое.
    :param num:
    :return:
    """
    # это флаг, который функция будет возвращать
    flag = True
    if num != 1:
        # это счетчик делителей числа
        counter = 0
        # это потенциальные делители числа
        d = 0
        while d <= num:
            d += 1
            if num % d == 0:
                counter += 1
                if counter > 2:
                    flag = False
                    break
    else:
        return False
    return flag


def left_cut(num: int) -> bool:
    """
    Эта функция срезает цифры слева.
    :param num:
    :return: bool
    """
    for i in range(len(str(num)) - 1, 0, -1):
        if not is_it_simple_number(num % (10 ** i)):
            return False
    return True


def right_cut(num: int) -> bool:
    """
       Эта функция срезает цифры справа.
       :param num:
       :return: bool
       """
    for i in range(1, len(str(num))):
        if not is_it_simple_number(num // (10 ** i)):
            return False
    return True


def generate() -> list:
    """
    Это главная функция, которая и возвращает список чисел, подлежащих условию задачи.
    :return: list
    """
    num = 10
    list_with_simple_number = []
    while len(list_with_simple_number) != 11:
        num += 1
        if is_it_simple_number(num) and left_cut(num) and right_cut(num):
            list_with_simple_number.append(num)
    else:
        return list_with_simple_number