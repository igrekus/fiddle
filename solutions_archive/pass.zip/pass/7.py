import random


def password(length: int, use_upper=False, use_digits=False) -> str:
    if length < 8:
        raise ValueError('Minimal password length is 8')
    a_low = lambda: random.randrange(97, 123)
    a_upp = lambda: random.randrange(65, 91)
    digi_ = lambda: random.randrange(48, 58)
    alphabets = [a_low, ]
    if use_upper:
        alphabets.append(a_upp)
    if use_digits:
        alphabets.append(digi_)

    res_l = [random.choice(alphabets)() for _ in range(length)]

    if use_upper or use_digits:
        set_ = set()
        while len(set_) < 3:
            set_.add(random.randrange(length))

        if use_upper:
            res_l[set_.pop()] = a_upp()
        if use_digits:
            res_l[set_.pop()] = digi_()
        res_l[set_.pop()] = a_low()

    return ''.join([chr(i) for i in res_l])