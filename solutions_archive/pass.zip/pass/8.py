import random


def password(length: int, use_upper=False, use_digits=False) -> str:
    if length < 8:
        raise ValueError("Minimal password length is 8")

    LETTERS_LOW = "abcdefghijklmnopqrstuvwyz"
    DIGITS = "0123456789"

    upper_count = 0
    upper_part = []
    digits_count = 0
    digits_part = []
    
    
    if use_upper:
        letters_upper = LETTERS_LOW.upper()
        upper_count = random.randint(1, (length//2)-1)
        upper_part = [random.choice(letters_upper) for _ in range(upper_count)]
    if use_digits:
        digits_count = random.randint(1, (length//2)-1)
        digits_part = [random.choice(DIGITS) for _ in range(digits_count)]

    low_count = length - upper_count - digits_count
    low_part = [random.choice(LETTERS_LOW) for _ in range(low_count)]

    pass_list = low_part + upper_part + digits_part
    random.shuffle(pass_list)

    return "".join(pass_list)
