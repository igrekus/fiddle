import string
import random


def generate_random_string(length: int, choices: list) -> str:
    if not choices:
        choices = (string.ascii_letters, )

    all_choices = "".join(choices)
    result = []
    choice_index = 0
    while len(result) < length:
        if choice_index < len(choices):
            char = random.choice(choices[choice_index])
            result.append(char)
            choice_index += 1
            continue
        char = random.choice(all_choices)
        result.append(char)
    random.shuffle(result)
    return "".join(result)


def password(length: int, use_upper=False, use_digits=False) -> str:
    if length < 8:
        raise ValueError("Minimal password length is 8")
    choices = [string.ascii_lowercase]
    if use_upper:
        choices.append(string.ascii_uppercase)
    if use_digits:
        choices.append(string.digits)
    return generate_random_string(length, choices)