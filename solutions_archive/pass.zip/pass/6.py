import random


def password(length: int, use_upper=False, use_digits=False) -> str:
	if length < 8: raise ValueError("Minimal password length is 8")
	our_password = ''
	alp = {
		'lower' : 'qwertyuiopasdfghjklzxcvbnm',
		'upper' : 'QWERTYUIOPASDFGHJKLZXCVBNM',
		'digits' : '0123456789'
	}
	p_to_use = alp['lower']
	if use_digits: p_to_use += alp['digits']

	count_upper = 0 if use_upper else 1
	count_digits = 0 if use_digits else 1
	count_lower = 0

	work = True
	while work:
		work = False
		for i in range(length):
			rand = random.choice(p_to_use)
			if use_digits and (rand in alp['digits']):
				count_digits = count_digits + 1
			elif use_upper and (rand in alp['lower'] and random.randint(1, 3) == 3):
				rand = rand.upper()
				count_upper = count_upper + 1
			else:
				count_lower += 1
			our_password += rand

		if use_upper and not count_upper:
			work = True
		if use_digits and not count_digits:
			work = True
		if not count_lower:
			work = True
		if work:
			count_lower = 0
			count_digits = 0
			count_upper = 0
			our_password = ''

	return our_password

