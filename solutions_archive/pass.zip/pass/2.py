import random
import string


def password(length: int, use_upper=False, use_digits=False):
    if length < 8:
        raise ValueError('Minimal password length is 8')
    lower_pool = string.ascii_lowercase
    upper_pool = string.ascii_uppercase if use_upper else ""
    digits_pool = string.digits if use_digits else ""
    pool = lower_pool + upper_pool + digits_pool
    while True:
        answer = [random.choice(pool) for _ in range(length)]
        is_lowers = any(x.islower() for x in answer)
        is_uppers = any(x.isupper() for x in answer) if use_upper else True
        is_digits = any(x.isdigit() for x in answer) if use_digits else True
        if is_lowers and is_uppers and is_digits:
            break
    return ''.join(answer)