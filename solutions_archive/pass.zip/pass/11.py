from random import randint, shuffle

def password(length: int, use_upper=False, use_digits=False) -> str:
    if length < 8:
        raise ValueError('Minimal password length is 8')
    lower = 0
    upper = 0
    digits = 0
    if use_upper and use_digits:
        lower = randint(1, length - use_upper - use_digits)
        upper = randint(1, length - lower - use_digits)
        digits = length - lower - upper
    if use_upper and not use_digits:
        lower = randint(1, length - 1)
        upper = length - lower
    if not use_upper and use_digits:
        lower = randint(1, length - 1)
        digits = length - lower
    if not use_upper and not use_digits:
        lower = length
    word = [chr(randint(ord('a'), ord('z'))) for i in range(lower)] + [chr(randint(ord('A'), ord('Z'))) for i in range(upper)] + [chr(randint(ord('0'), ord('9'))) for i in range(digits)]
    shuffle(word)
    return ''.join(word)
