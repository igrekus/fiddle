from string import ascii_lowercase, digits
from random import sample, randint


def password(length: int, use_upper=False, use_digits=False) -> str:
    minimal_length = 8
    if length < minimal_length:
        raise ValueError(f'Minimal password length is {minimal_length}')
    letters = ascii_lowercase if length <= 26 else ascii_lowercase * (length // 26 + 1)
    alphabet = sample(letters, k=length)
    if use_upper:
        for i in range(0, length, 4):
            alphabet[i] = alphabet[i].upper()
    if use_digits:
        for i in range(1, length, 3):
            alphabet[i] = digits[randint(0, 9)]
    return ''.join(alphabet)