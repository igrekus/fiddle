import random


def password(length: int, use_upper=False, use_digits=False) -> str:
   
    if length < 8:
        raise ValueError("Minimal password length is 8")
   
    upper = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    digits = '1234567890'
    chars = 'abcdefghijklnopqrstuvwxyz'
   
    password_list = []
 
    for i in range(length-use_upper-use_digits):
        password_list.append(random.choice(chars))
   
    if use_upper==True:
        password_list.append(random.choice(upper))
    if use_digits==True:
        password_list.append(random.choice(digits))
       
    # раз минимум одну заглавную и одну цифру, то пусть они и будут по одной!
       
    random.shuffle(password_list)
    password = ''.join(password_list)
           
    return password