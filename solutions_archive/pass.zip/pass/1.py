import random
import string

MIN_PASS_LENGTH = 8
LOWERCASE = string.ascii_lowercase
UPPERCASE = string.ascii_uppercase
DIGITS = string.digits


def password(length: int, use_upper=False, use_digits=False) -> str:
    if length < MIN_PASS_LENGTH:
        raise ValueError('Minimal password length is 8')

    symbols_set = f'{LOWERCASE}'
    if use_upper:
        symbols_set = f'{symbols_set}{UPPERCASE}'

    if use_digits:
        symbols_set = f'{symbols_set}{DIGITS}'

    while True:
        full_conditions = True

        result = [random.choice(symbols_set) for _ in range(length)]

        if use_upper:
            check_upper_length = len([_ for _ in result if _ in UPPERCASE])
            # The number of uppercase letters is less than 1 or all letters are uppercase
            if check_upper_length < 1 or check_upper_length == len(result):
                full_conditions = False

        if use_digits:
            check_digit_length = len([_ for _ in result if _ in DIGITS])
            # The number of digits is less than 1 or all letters are digits
            if check_digit_length < 1 or check_digit_length == len(result):
                full_conditions = False

        if use_upper and use_digits:
            check_lower_length = len([_ for _ in result if _ in LOWERCASE])
            # The number of lowercase letters is less than 1
            if check_lower_length < 1:
                full_conditions = False

        if full_conditions:
            break

        # This is not necessary, but it will not hurt.
        shuffled = list(symbols_set)
        random.shuffle(shuffled)
        symbols_set = ''.join(shuffled)

    return ''.join(result)
