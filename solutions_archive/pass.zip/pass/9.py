from string import ascii_uppercase, ascii_lowercase, digits
import random


def password(length: int, use_upper=False, use_digits=False) -> str:
    """
    The function creates a password from a sequence of characters in different case and numbers.

    :param length: Number of characters in the password. Minimum length 8.
    :param use_upper: If True, then at least one upper case characters will be added to the password. Default False.
    :param use_digits: If True, then at least one digits will be added to the password. Default False.
    :return: Generated password
    """

    if length < 8:
        raise ValueError('Minimal password length is 8')
    combination = ascii_lowercase
    final_password = []
    final_password.append(random.choice(ascii_lowercase))

    if use_upper:
        final_password.append(random.choice(ascii_uppercase))
        combination += ascii_uppercase

    if use_digits:
        final_password.append(random.choice(digits))
        combination += digits

    for _ in range(length - len(final_password)):
        final_password += random.choice(combination)

    random.shuffle(final_password)
    return ''.join(final_password)