def ascending(value: str) -> bool:
    for i in range(1, len(value) // 2 + 1):
        current_num = int(value[0:i])
        sequence = ""
        while len(sequence) < len(value):
            sequence += str(current_num)
            current_num += 1
            if sequence == value:
                return True
    return False

