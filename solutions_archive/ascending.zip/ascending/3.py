def ascending(value:str) -> bool:
    start = k = 0
    end = count =1
    while k <len(value)//2:
        numbers = []
        while start <len(value):
            numbers.append(value[start:end])
            start +=count
            end +=count
        for j in range(1,len(numbers)):
            if int(numbers[j])-int(numbers[j-1])!=1: 
                break
        else:
            return True
        k+=1
        count =(1+k)
        start = 0
        end = count
    return False

