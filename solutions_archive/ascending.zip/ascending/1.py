def ascending(value: str) -> bool:
    for length in range(1, (len(value) // 2) + 1):
        if is_asc(value, length):
            return True
    return False


def is_asc(value: str, length: int) -> bool:
    if len(value) <= length:
        return False
    position = 0
    while True:
        current = int(value[position:position + length])
        must_be = str(current + 1)
        if must_be != value[position + length:position + length + len(must_be)]:
            return False
        position += length
        if length < len(must_be):
            length = len(must_be)
        if position >= len(value) - len(must_be):
            break
    return True



# #task Напишите функцию, которая возвращает True если строка, которая является аргументом функции содежит возрастающие И последовательные числа.
# `def ascending(value: str) -> bool:`
# Примеры:
# ascending("232425") вернет True, так как строку можно представить как 23, 24, 25 (следуют друг за другом по возрастанию)
# ascending("2324256") ➞ False шестерка в конце ломает возрастающий ряд
# ascending("444445") ➞ True так как строку можно представить как 444 и 445.
# Предполагается, что строка никогда не пустая и всегда содержит минимум 2 числа, например '10' -валидная строка
# Сигнатуру функции не менять! Вот прямо совсем не менять(!), но можно использовать свои дополнительные функции и классы,
# ничего не импортируем, исключений не кидаем. Решение слать мне в личку модулем питона.
# ВСЕ, кто пришлет решения в следующую субботу получат все решаения других участников для ознакомления.

