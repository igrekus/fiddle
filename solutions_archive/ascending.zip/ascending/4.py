def recursion(string: str, current_num: int, expected_num: int) -> bool:
    if not string:
        return True
    index = len(str(expected_num))
    if str(expected_num) == string[:index]:
        string = string[index:]
        current_num = expected_num
        expected_num += 1
        if recursion(string, current_num, expected_num):
            return True
    else:
        return False


def ascending(value: str) -> bool:
    for i in range(1, len(value) // 2 + 1):
        current_num = int(value[0:i])
        expected_num = current_num + 1
        if recursion(value[i:], current_num, expected_num):
            return True
    return False
            
    
    
    
            
            
