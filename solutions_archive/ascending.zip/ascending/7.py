def ascending(value: str) -> bool:
    if len(value) == 2:
        if int(value[1]) - int(value[0]) == 1:
            return True
        else:
            return False
    length = 1
    while length <= len(value) // 2 + 1:
        current_length = length
        fragments = []
        index = 0
        while index < len(value) - current_length:
            if int(value[index:index + current_length]) + 1 == \
                    int(value[index + current_length:index + current_length * 2]):
                fragments.append(int(value[index:index + current_length]))
                index += current_length
                continue
            if int(value[index:index + current_length]) + 1 == \
                    int(value[index + current_length:index + current_length * 2 + 1]):
                fragments.append(int(value[index:index + current_length]))
                index += current_length
                current_length += 1
                continue
            break
        else:
            if fragments == sorted(fragments) and len(set(fragments)) == len(fragments) \
                    and int(fragments[-1]) - int(fragments[0]) + 1 == len(fragments):
                return True
        length += 1
    return False


if __name__ == '__main__':
    print(ascending("12"))
