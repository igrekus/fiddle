
def ascending(value: str):
    for j in range(len(value)):
        new_val = value[:j + 1]
        int_val = int(new_val)
        while len(new_val) < len(value):
            int_val += 1
            new_val = f'{new_val}{int_val}'
            print(new_val)
            if new_val == value:
                return True
    return False


if __name__ == '__main__':
    print(ascending('123124125'))

