def ascending(value: str) -> bool:
    maxLength = 1
    flag = False
    while (
        maxLength <= len(value) // 2
    ):  # если число больше половины длины последовательности то выходим

        n, offset = 0, maxLength
        while n < len(value):

            current = int(value[n : n + offset])
            next = current + 1
            sizeNext = len(str(next))
            tmp = offset
            offset = sizeNext
            if n + sizeNext + 1 > len(value):
                break
            if int(value[n + tmp : n + sizeNext + tmp]) == next:
                flag = True
            else:
                flag = False
                break
            n += tmp
        if flag:
            break
        maxLength += 1
    return flag
