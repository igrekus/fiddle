def ascending(value: str) -> bool:
    if value[0] == '-':
        start = 1
    else:
        start = 0
    for i in range(start, round(len(value) / 2)):
        if value[0] == '-':
            if '-' in value[1:i + 1]:
                return False
            current = -int(value[1:i + 1])
        else:
            if '-' in value[:i + 1]:
                return False
            current = int(value[:i + 1])
        numbers = str(current)

        while len(numbers) < len(value):
            current += 1
            numbers += str(current)

        if numbers == value:
            return True

    return False
