class Vending:
    price_list = {"JAVA": 50, "Nesquick": 40, "Latte": 50, "Tea": 20}

    def __init__(self):
        self.balance = 0
        self.content = dict.fromkeys(self.price_list.keys(), 5)

    @staticmethod
    def get_help():
        print("Доступные команды: ('помощь', 'взять', 'внести', 'сдача', 'выход')")

    def get_drink(self, drink):
        if drink not in self.price_list:
            return
        elif self.balance < self.price_list.get(drink):
            print("Сумма недостаточна! Внесите еще монет")
        elif self.content.get(drink) <= 0:
            print("Не осталось данного напитка!")
        else:
            print(f"Выдан {drink}")
            self.balance -= self.price_list.get(drink)
            self.content[drink] -= 1

    def deposit(self, cash):
        if cash.isdigit():
            self.balance += int(cash)

    def get_change(self):
        print(f"Возвращено:{self.balance}")
        self.balance = 0


def run():
    vending = Vending()
    commands = {"помощь": vending.get_help,
                "взять": vending.get_drink,
                "внести": vending.deposit,
                "сдача": vending.get_change}
    while True:
        print(f"Напитки: {list(vending.price_list.keys())} Баланс: {vending.balance}")
        try:
            command, *params = input("Введите команду>>>:").split()
            command = command.lower()
            if command == "выход":
                break
            if command in commands:
                commands.get(command)(*params)
        except (ValueError, TypeError):
            continue


if __name__ == "__main__":
    run()
