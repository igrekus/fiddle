from dataclasses import dataclass
from typing import List, Optional, Union


class VendingMachineException(Exception):
    error_message = ""

    def __str__(self):
        if not self.args:
            return self.error_message

        return object.__str__(self)


class NoMoreDrinksError(VendingMachineException):
    error_message = "напитков больше нет"


class ThereIsNoDrinkInTheVendingMachineError(VendingMachineException):
    error_message = "в торговом автомате нет данного напитка"


class ThereIsNothingOnTheBalanceSheetError(VendingMachineException):
    error_message = "на балансе ничего нет"


class NotEnoughBalanceError(VendingMachineException):
    error_message = "недостаточно баланса"


@dataclass
class Drink:
    """Объект напитка.

    Экземляры этого класса имеют атрибуты name, cost и quantity.

    Данный класс экспортирует следующий метод:
        take_one_drink  Уменьшает на 1 кол-во напитков.
    """
    name: str
    cost: int
    quantity: int

    def take_one_drink(self):
        """Уменьшает количество напитка на 1."""
        if self:
            self.quantity -= 1
        else:
            raise NoMoreDrinksError

    def __repr__(self):
        return self.name.__repr__()

    def __eq__(self, other: str):
        if isinstance(other, str):
            return self.name.casefold() == other.casefold()

        return (self.name.casefold() == other.name.casefold()
                    and self.cost == other.cost
                    and self.quantity == other.quantity)

    def __bool__(self):
        return self.quantity > 0


@dataclass
class VendingMachineBase:
    """Объект торгового автомата.

    Экземляры данного класса имеют атрибуты drinks, который содержит список
    объектов напитков, и balance.

    Данный класс экспортирует следующие методы:
        get_drink       Возвращает экземляр Drink'а и уменьшает баланс и
                        количество этого напитка.
        top_up_balance  Повышает баланс.
        get_change      Возвращает сдачу.
    """
    drinks: List[Drink]
    balance: int = 0

    def print_drink(self, name: str) -> Drink:
        """Возвращает экземляр Drink'а и уменьшает баланс и количество этого
        напитка.

        Поднимает NotEnoughBalanceError при недостатке баланса.  Поднимает
        ThereIsNoDrinkInTheVendingMachineError при отсутствии напитка в
        торговом автомате.
        """
        for drink in self.drinks:
            if drink == name:
                if self.balance >= drink.cost:
                    drink.take_one_drink()
                    self.balance -= drink.cost
                else:
                    raise NotEnoughBalanceError

                return drink

        raise ThereIsNoDrinkInTheVendingMachineError

    def top_up_balance(self, balance: int):
        """Повышает баланс, если передано целочисленное число, которое больше 0.

        Поднимает ValueError, если условие выше не удовлетворено.
        """
        if isinstance(balance, int):
            if balance > 0:
                self.balance += balance
        else:
            raise ValueError

    def print_change(self) -> int:
        """Возвращает сдачу.

        Поднимает ThereIsNothingOnTheBalanceSheetError, если баланс равен нулю.
        """
        if (balance := self.balance) > 0:
            self.balance = 0
            return balance

        raise ThereIsNothingOnTheBalanceSheetError

    def __str__(self):
        return f"Напитки: {self.drinks} Баланс: {self.balance}"


class VendingMachine(VendingMachineBase):
    def print_drink(self, name: str):
        """Настроенная версия VendingMachineBase.get_drink.

        Печатает f"Выдан {name}" при отсутствии исключений.  Перехватывает
        NoMoreDrinksError и печатает "Не осталось данного напитка".
        Перехватывает NotEnoughBalanceError и печатает "Сумма недостаточна!
        Внесите еще монет".  Перехватывает ThereIsNoDrinkInTheVendingMachineError.
        """
        try:
            drink = VendingMachineBase.print_drink(self, name)
            print(f"Выдан {drink.name}")
        except NoMoreDrinksError:
            print("Не осталось данного напитка!")
        except NotEnoughBalanceError:
            print("Сумма недостаточна! Внесите еще монет")
        except ThereIsNoDrinkInTheVendingMachineError:
            pass

    def top_up_balance(self, balance: Union[int, str]):
        """Настроенная версия VendingMachineBase.top_up_balance.

        Перехватывает ValueError.
        """
        try:
            VendingMachineBase.top_up_balance(self, int(balance))
        except ValueError:
            pass

    def print_change(self):
        """Настроенная версия VendingMachineBase.get_change.

        Печатает f"Возвращено {change}" при отсутствии исключений.
        Перехватывает ThereIsNothingOnTheBalanceSheetError.
        """
        try:
            change = VendingMachineBase.print_change(self)
            print(f"Возвращено:{change}")
        except ThereIsNothingOnTheBalanceSheetError:
            pass


def run():
    """Создаёт объект торгового автомата и печатает приглашение к вводу."""
    vending_machine = VendingMachine([
        Drink('JAVA', 50, 5),
        Drink('Nesquick', 50, 5),
        Drink('Latte', 40, 5),
        Drink('Tea', 20, 5),
    ])
    print(vending_machine)
    commands = {
        'помощь': (lambda: print("Доступные команды:"
                    + " ('помощь', 'взять', 'внести', 'сдача', 'выход')")),
        'взять': (lambda name: vending_machine.print_drink(name)),
        'внести': (lambda balance: vending_machine.top_up_balance(balance)),
        'сдача': (lambda: vending_machine.print_change()),
        'выход': (lambda: exit()),
    }

    def run_cmd(cmd: str, arg: Optional[str] = None):
        """"""
        try:
            commands[cmd](arg)
        except TypeError:
            commands[cmd]()
        except KeyError:
            pass

    while True:
        user_input = input("Введите команду: ").casefold()
        if user_input =='выход':
            break
        try:
            run_cmd(*user_input.split())
        except TypeError:
            pass
        print(vending_machine)


if __name__ == '__main__':
    run()
