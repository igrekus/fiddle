class Machine:
    def __init__(self):
        self.balance: int = 0
        self.drinks: dict = {
            "JAVA": {
                "cost": 50,
                "count": 5
            },
            "Nesquick": {
                "cost": 40,
                "count": 5
            },
            "Latte": {
                "cost": 50,
                "count": 5
            },
            "Tea": {
                "cost": 20,
                "count": 5
            }
        }

        self.commands: dict = {
            "помощь": self.help,
            "взять": self.take,
            "внести": self.deposit,
            "сдача": self.surrender,
        }
        self.commands_to_show: list = ["помощь",
                                       "взять",
                                       "внести",
                                       "сдача",
                                       "выход"]

    def run(self):
        while True:
            print(f"Напитки: {[key for key in self.drinks.keys()]} Баланс: {self.balance}")
            full_command = input("Введите команду>>>: ")
            first_item = full_command.split()[0].lower()
            if first_item in self.commands.keys():
                if first_item in ["помощь", "сдача"]:
                    self.commands[first_item]()
                else:
                    arg = full_command.split()[1]
                    self.commands[first_item](arg)
            if first_item == "выход":
                break

    def help(self):
        print(f"Доступные команды: "
              f"{' '.join([command for command in self.commands_to_show])}")

    def take(self, drink):
        if drink in self.drinks.keys():
            if self.balance < self.drinks[drink]["cost"]:
                print("Сумма недостаточна! Внесите еще монет")
                return
            if self.drinks[drink]["count"] == 0:
                print("Не осталось данного напитка!")
                return

            print(f"Выдан {drink}")
            self.drinks[drink]["count"] -= 1
            self.balance -= self.drinks[drink]["cost"]

    def deposit(self, money):
        try:
            money = int(money)
            if money > 0:
                self.balance += money
        except ValueError:
            return

    def surrender(self):
        print(f"Возвращено:{self.balance}")
        self.balance = 0


def run():
    Machine().run()


if __name__ == "__main__":
    run()
