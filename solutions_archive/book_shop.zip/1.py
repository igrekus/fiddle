#!/usr/bin/env python
"""
ТЗ:

Фрилансер Василий получил от книжного магазина "Зелёный змий" заказ на доработку системы складского учёта. Суть такова...
    - товары теряют ценность по мере приближения указанноего срока реализации товара
    - у всех товаров есть свойство sell_in, показывающее количество дней, оставшееся до окончания срока реализации
    - у всех товаров есть свойство quality, описывающее ценность товара
    - в конце каждого дня, система производит автоматический перерасчёт срока годности и показателя качества для всех товаров на складе

Система достаточно простая, но есть пара ньюансов:
    - по истечению срока продажи, параметр quality уменьшается вдвое быстрее
    - quality не может быть отрицательным, но может быть равным нулю
    - quality не может превышать 50
    - KNUT с возрастом только хорошеет
    - LUTZ - легендартный артефакт, не терят в качестве и продавать его нельзя
    - quality 3го тома Лутца равно 80 и никогда не меняется
    - DISCOUNT_COUPON, также как книга Вирта, набирает ценность по мере истечения срока годности:
        - на 1, если осталось больше 10 дней
        - за 10 и менее дней до истечения срока ценность увеличивается на 2 в день
        - за 5 и менее дней до истечения срока ценность увеличивается на 3 в день
        - по истечению срока, ценность падает до нуля

Далее, поставщик впарил магазину серию книг по фреймворкам, и задачей Василия будет внесение следующей доработки в систему:
    - любоая литература со словом "фреймворк" в названии устаревает в 2 раза быстрее

Василий, несмотря на то, что фрилансер, калач уже тёрнтый и поэтому прекрасно понимает, что заказчик обычно не технарь и
ТЗ пишет через задницу, поэтому __поведение системы придётся уточнять через анализ существубщего кода__.
Василий может вносить __любые__ изменения в код метода update_quality(), главное, чтобы существующий контракт не менялся.
Класс Item __трогать нельзя__, так как его писал психопат, который знает, где Василий живёт. С другой стороны, психопат
код писать всё-такие умел и `Item` из БД приходит всегда валидный.
"""

from dataclasses import dataclass
from typing import List

KNUT = 'Д. Кнут, Искусство программирования'
LUTZ = 'Марк Лутц, Изучаем Python, 3й том'
DISCOUNT_COUPON = 'Скидочный купон на курс'


@dataclass
class Item:
    name: str = ''
    sell_in: int = 0
    quality: int = 0


class BookShop:
    def __init__(self, items: List[Item]):
        self.items = items

    def update_quality(self):
        for item in self.items:
            is_framework = 2 if 'фреймворк' in item.name.casefold() else 1

            if (item.name not in (KNUT, DISCOUNT_COUPON, LUTZ)
                    and item.quality > 0):
                item.quality -= 1 * is_framework
            elif 0 < item.quality < 50:
                item.quality += 1

                if item.name == DISCOUNT_COUPON:
                    if item.sell_in < 11 and item.quality < 50:
                        item.quality += 1
                    if item.sell_in < 6 and item.quality < 50:
                        item.quality += 1

            if item.name != LUTZ:
                item.sell_in -= 1

            if item.sell_in < 0:
                if item.name != KNUT:
                    if (item.name not in (DISCOUNT_COUPON, LUTZ)
                            and item.quality > 0):
                        item.quality -= 1 * is_framework
                    elif item.name != LUTZ:
                        item.quality -= item.quality
                elif item.quality < 50:
                    item.quality += 1


def _test():
    asserts = [(Item(), (-1, 0)),
               (Item(KNUT, 50, 48), (49, 49)),
               (Item(KNUT, 0, 30), (-1, 32)),
               (Item(LUTZ, 30, 80), (30, 80)),
               (Item(LUTZ, 0, 80), (0, 80)),
               (Item(LUTZ, -1, 80), (-1, 80)),
               (Item(DISCOUNT_COUPON, 15, 30), (14, 31)),
               (Item(DISCOUNT_COUPON, 10, 30), (9, 32)),
               (Item(DISCOUNT_COUPON, 3, 30), (2, 33)),
               (Item(DISCOUNT_COUPON, 0, 30), (-1, 0)),
               (Item(DISCOUNT_COUPON, 3, 49), (2, 50)),
               (Item('', 0, 10), (-1, 8)),
               (Item('', 2, 2), (1, 1)),
               (Item('', 2, 0), (1, 0)),
               (Item('фреймворк', 0, 4), (-1, 0)),
               (Item('фреймворк', 4, 14), (3, 12)),
               (Item('ФреЙмВорк', 40, 49), (39, 47)),
               (Item('Фреймворк', 2, 0), (1, 0))]

    shop = BookShop(list(i[0] for i in asserts))
    shop.update_quality()

    for n, (i, (sell_in, quality)) in enumerate(asserts):
        assert i.sell_in == sell_in and i.quality == quality, f"проблема с {i} {asserts[n][1]}"

    print("Все тесты прошли успешно")


if __name__ == '__main__':
    _test()

