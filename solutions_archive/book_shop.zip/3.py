from dataclasses import dataclass


@dataclass()
class Item:
    name: str = ''
    sell_in: int = 0
    quality: int = 0


class BookShop:
    DISCOUNT = 'Скидочный купон на курс'
    KNUTH = 'Д. Кнут, Искусство программирования'
    LUTZ = 'Марк Лутц, Изучаем Python, 3й том'
    FRAMEWORK = 'фреймворк'
    MAX_QUALITY = 50
    LUTZ_QUALITY = 80

    def __init__(self, items: list):
        self.items: list = items
        self.items = list(map(BookShop._validate_item, self.items))

    def __str__(self):
        return str([(item.name, item.sell_in, item.quality) for item in self.items])

    @staticmethod
    def _validate_item(item: Item):
        if item.name == BookShop.LUTZ:
            item.quality = BookShop.LUTZ_QUALITY
        elif item.quality > BookShop.MAX_QUALITY:
            item.quality = BookShop.MAX_QUALITY
        elif item.quality < 0:
            item.quality = 0
        return item

    @staticmethod
    def _get_quality(item: Item):
        _default_change = lambda i: (i.quality - (1 + 1 * (i.sell_in <= 0)) *
                                     (1 + 1 * (BookShop.FRAMEWORK in i.name.lower())))
        changes = {BookShop.LUTZ: lambda i: BookShop.LUTZ_QUALITY,
                   BookShop.KNUTH: lambda i: i.quality + 1 + 1 * (i.sell_in <= 0),
                   BookShop.DISCOUNT: lambda i: (i.quality + 1 + sum(1 for j in (6, 11) if i.sell_in < j)) *
                                                (i.sell_in > 0)}
        quality = changes.get(item.name, _default_change)(item)
        if quality < 0:
            quality = 0
        return quality if quality < BookShop.MAX_QUALITY or item.name == BookShop.LUTZ else BookShop.MAX_QUALITY

    @staticmethod
    def _get_sell_in(item: Item):
        return item.sell_in - 1 * (item.name != BookShop.LUTZ)

    def update_quality(self):
        for item in self.items:
            item.quality = BookShop._get_quality(item)
            item.sell_in = BookShop._get_sell_in(item)


if __name__ == '__main__':
    from random import randint

    s1, s2 = -5, 15
    q1, q2 = -10, 60
    for _ in range(10):
        items = [Item(name='Д. Кнут, Искусство программирования', sell_in=randint(s1, s2), quality=randint(q1, q2)),
                 Item(name='Марк Лутц, Изучаем Python, 3й том', sell_in=randint(s1, s2), quality=randint(q1, q2)),
                 Item(name='Скидочный купон на курс', sell_in=randint(s1, s2), quality=randint(q1, q2)),
                 Item(name='ReactJS фреймворк', sell_in=randint(s1, s2), quality=randint(q1, q2)),
                 Item(name='Н. Вирт, Алгоритмы и структуры данных', sell_in=randint(s1, s2), quality=randint(q1, q2)),
                 Item(name='Телебот. Модуле нот фаунд. Что делать?', sell_in=randint(s1, s2), quality=randint(q1, q2))]
        shop = BookShop(items)
        for __ in range(20):
            shop.update_quality()
            print(shop)
        print()
