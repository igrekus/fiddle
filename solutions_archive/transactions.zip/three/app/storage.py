from .changelog import *
from .commands import Commands


class Storage:
    """
    The class implements the logic of interaction with the data store.
    """
    __slots__ = ('__changelog', '__storage_instance')

    def __init__(self, change_log: ChangeLog = None):
        self.__changelog = change_log or ChangeLog()
        self.__storage_instance = {}

    def get(self, name):
        """
        Returns a value by name.
        :param name: The name by which the value is stored.
        :return: Returns stored value.
        """
        return self.__storage_instance.get(name, 'NULL')

    def set(self, name, value):
        """
        Saves the value under the name `name`.
        :param name: The name with which the value will be stored.
        :param value: The value to be stored in the database.
        """
        self.__changelog.add_event(Event(Commands.SET.value, name, value))
        self.__storage_instance[name] = value

    def unset(self, name):
        """
        Removes a value from the database.
        :param name: The name with which the value is stored.
        """
        if name in self.__storage_instance:
            self.__changelog.add_event(Event(Commands.UNSET.value, name, self.__storage_instance[name]))
            del self.__storage_instance[name]

    def count_element(self, value):
        """
        Returns how many values (`value`) are stored in the database.
        :param value: The amount of which you want to know.
        :return: The number of elements in the database.
        """
        return list(self.__storage_instance.values()).count(value)

    def begin_transaction(self):
        """
        Begins a transaction.
        """
        change_list = self.__changelog.change_list
        if change_list and change_list[-1].command == Commands.BEGIN_TRANSACTION.value:
            return
        self.__changelog.add_event(Event(Commands.BEGIN_TRANSACTION.value))

    def commit_transaction(self):
        """
        Commits transaction and optimizes changelog.
        """
        while True:
            index = self.__changelog.last_event_index(Commands.BEGIN_TRANSACTION.value)
            if index is None:
                break
            del self.__changelog.change_list[index]
        for x in self.__changelog.reverse_read():
            self.__changelog.optimize(x)

    def log(self):
        """
        Return enumeration from the list of changes.
        :return: Enumeration from the list of changes.
        """
        return enumerate(self.__changelog.change_list, 1)

    def rollback_transaction(self) -> bool:
        """
        Rollback an internal transaction
        :return: True if the transaction was successfully canceled.
        :rtype: bool
        """
        revert_events = self.__changelog.remove_to(Commands.BEGIN_TRANSACTION.value)
        self.__apply_events(revert_events, self.__unset_action, self.__set_action)
        self.__apply_events(self.__changelog.change_list, self.__set_action, self.__unset_action)
        return True

    def __unset_action(self, event: Event):
        del self.__storage_instance[event.name]

    def __set_action(self, event: Event):
        self.__storage_instance[event.name] = event.value

    def __apply_events(self, events: typing.Iterable, set_callback, unset_callback):
        """
        Apply changes from the changelog to the database.

        :param events: List of changes from the change log to be applied.
        :return:
        """
        for event in events:
            if event.command == Commands.SET.value:
                set_callback(event)
            elif event.command == Commands.UNSET.value and event.name in self.__storage_instance:
                unset_callback(event)

    def __str__(self):
        return str(self.__storage_instance)
