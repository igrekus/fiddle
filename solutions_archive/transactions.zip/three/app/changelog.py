import typing
from .commands import Commands
import collections


class Event(typing.NamedTuple):
    """
    Contains basic information about the action in the change log.
    """
    command: str
    name: typing.Any = None
    value: typing.Any = None

    def is_modify_event(self) -> bool:
        """
        Checks for event modifies database data.
        :return: True if the event changes data in the database.
        """
        return self.command in [Commands.SET.value, Commands.UNSET.value]


class ChangeLog:
    """
    Responsible for logging changes.
    Contains the necessary methods for interacting with the Change Log.
    """
    __slots__ = ('change_list')

    def __init__(self):
        self.change_list = collections.deque()

    def optimize(self, event: Event):
        """
        Optimizes change log.

        :param event: Event to be optimized.
        """
        if not event.is_modify_event():
            return

        if self.change_list:
            index = self.last_event_index(Commands.BEGIN_TRANSACTION.value) or 0
            while index < len(self.change_list):
                item = self.change_list[index]
                if item is event:
                    break
                if event.is_modify_event() and item.name == event.name:
                    del self.change_list[index]
                index += 1

    def add_event(self, event):
        """
        Add an event to the change log.

        :param event: The event to be added to the change log.
        """
        self.optimize(event)
        self.change_list.append(event)

    def read(self):
        """
        Reads the change log from the beginning.

        :return: Returns an event generator from the change log.
        """
        yield from self.change_list

    def reverse_read(self):
        """
        Reads the change log from the end.

        :return: Returns an event generator from the change log.
        """
        index = len(self.change_list) - 1

        while index >= 0:
            yield self.change_list[index]
            index -= 1

    def last_event_index(self, event_name: str) -> typing.Optional[int]:
        """
        Searches the index of the last added event by name.

        :param event_name: The name of the event to be found in the change log.
        :return: last added event index or None.
        """
        event_name = event_name.upper()
        change_list_len = len(self.change_list)

        for index, event in enumerate(self.reverse_read()):
            if event.command == event_name:
                return (change_list_len - index) - 1
        return None

    def remove_to(self, event_name: str) -> typing.Generator[Event, None, None]:
        """
        Deletes all entries from the change list before the event named "event_name".

        :param event_name: The name of the event by which to remove events from the change log.
        :return: List of deleted eventsю
        """
        if self.last_event_index(event_name) is None:
            return None
        while len(self.change_list) != 0:
            transaction: Event = self.change_list.pop()
            if transaction.command == event_name:
                break
            yield transaction
