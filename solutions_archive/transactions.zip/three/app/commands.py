import abc
from enum import Enum

__all__ = ('CommandExecutor', 'InvalidSignatureException', 'InvalidCommandException', 'Commands')


class Commands(Enum):
    """
    Enumeration of all commands.
    """
    SET = 'SET'
    GET = 'GET'
    COUNTS = 'COUNTS'
    UNSET = 'UNSET'
    END = 'END'
    BEGIN_TRANSACTION = 'BEGIN'
    COMMIT_TRANSACTION = 'COMMIT'
    ROLLBACK_TRANSACTION = 'ROLLBACK'
    ALL = 'ALL'
    LOG = 'LOG'
    HELP = 'HELP'


class BaseCommand(metaclass=abc.ABCMeta):
    """
    Command class.
    """
    __slots__ = ('_storage')

    def __init__(self, storage):
        self._storage = storage

    @abc.abstractmethod
    def help(self) -> str:
        """
        Returns help information about the command.

        :return: Information about the command.
        """
        pass

    @abc.abstractmethod
    def execute(self, *args):
        """
        Command execution.

        :param args: Command arguments.
        """
        pass


class SetCommand(BaseCommand):
    __slots__ = ('_storage')

    def help(self) -> str:
        return 'Signature: `SET <key> <value>`.\nSaves to the app <value> with the key <key>.'

    def execute(self, key, value):
        self._storage.set(key, value)


class GetCommand(BaseCommand):
    __slots__ = ('_storage')

    def help(self) -> str:
        return 'Signature: `GET <key>`.\nReturns the value for <key>. If such a <key> is not in the app, then returns NULL.'

    def execute(self, key):
        print(self._storage.get(key))


class UnsetCommand(BaseCommand):
    __slots__ = ('_storage')

    def help(self) -> str:
        return 'Signature: UNSET <key>.\nDeletes data from the app using the key <key>.'

    def execute(self, key):
        self._storage.unset(key)


class CountsCommand(BaseCommand):
    __slots__ = ('_storage')

    def help(self) -> str:
        return 'Signature: `COUNTS <value>`.\nCounts how many <value> are stored in the app.'

    def execute(self, value):
        print(self._storage.count_element(value))


class BeginTransactionCommand(BaseCommand):
    __slots__ = ('_storage')

    def help(self) -> str:
        return 'Signature: `BEGIN`.\nBegin transaction.'

    def execute(self):
        self._storage.begin_transaction()


class CommitTransactionCommand(BaseCommand):
    __slots__ = ('_storage')

    def help(self) -> str:
        return 'Signature: `COMMIT`.\nCommit transaction.'

    def execute(self):
        self._storage.commit_transaction()


class RollbackTransactionCommand(BaseCommand):
    __slots__ = ('_storage')

    def help(self) -> str:
        return 'Signature: `ROLLBACK`.\nRollback inner transaction.'

    def execute(self):
        self._storage.rollback_transaction()


class EndCommand(BaseCommand):
    __slots__ = ('_storage')

    def help(self) -> str:
        return 'To stop working with the database.'

    def execute(self, *args):
        raise SystemExit(0)


class DataListCommand(BaseCommand):
    __slots__ = ('_storage')

    def help(self) -> str:
        return 'Displays all data in the database.'

    def execute(self, *args):
        print(self._storage)


class ChangelogCommand(BaseCommand):
    __slots__ = ('_storage')

    def help(self):
        return 'Displays a list of changes in the database.'

    def execute(self, *args):
        print(*self._storage.log(), sep='\n')


class InvalidCommandException(Exception):
    """
    This exception is raised if CommandExecutor cannot execute the command.
    """
    pass


class InvalidSignatureException(Exception):
    """
    This exception is raised if invalid arguments were passed to the command.
    """
    pass


class CommandExecutor:
    """
    The class is responsible for executing commands.
    """
    __slots__ = ('__commands', '__command_list')

    def __init__(self, storage):
        self.__commands = {
            Commands.GET.value: GetCommand(storage),
            Commands.SET.value: SetCommand(storage),
            Commands.COUNTS.value: CountsCommand(storage),
            Commands.UNSET.value: UnsetCommand(storage),
            Commands.END.value: EndCommand(storage),
            Commands.BEGIN_TRANSACTION.value: BeginTransactionCommand(storage),
            Commands.COMMIT_TRANSACTION.value: CommitTransactionCommand(storage),
            Commands.ROLLBACK_TRANSACTION.value: RollbackTransactionCommand(storage),
            Commands.ALL.value: DataListCommand(storage),
            Commands.LOG.value: ChangelogCommand(storage),
        }
        self.__command_list = list(self.__commands.keys())

    def execute_command(self, name, *args):
        """
        Executes the command "name" with arguments "args".

        :param name: Command name.
        :param args: Command arguments.
        """
        if name == Commands.HELP.value:
            for key, value in self.__commands.items():
                print(key, value.help(), '', sep='\n')
            return
        if name not in self.__commands:
            raise InvalidCommandException(f'Command "{name}" does not exist.')
        command_instance = self.__commands[name]
        try:
            return command_instance.execute(*args)
        except Exception:
            raise InvalidSignatureException(f'Invalid Signature.\n{command_instance.help()}')

    def command_list(self):
        return self.__command_list
