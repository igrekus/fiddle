import difflib
import os
from three.app.commands import *
from three.app.storage import Storage


IS_PROD = os.getenv('CRAP_PROD_ENV', False)


def input_parser(string: str) -> tuple:
    """
    Parsing the input string to the command and its arguments.

    :param string: String to parse.
    :return: a tuple in which the first element is a normalized command, and the second is the command arguments.
    """
    command, *data = string.split()
    return command.upper(), data


def run(storage: Storage = None):
    if IS_PROD:
        print('Welcome to the CRAP app. To find out which commands are available, write "help"')
    if not storage:
        storage = Storage()
    command_executor = CommandExecutor(storage)
    while True:
        try:
            input_string = input('>> ')
        except (KeyboardInterrupt, EOFError):
            if IS_PROD:
                print('\nBye')
            break

        if not input_string:
            break
        command, data = input_parser(input_string)
        try:
            command_executor.execute_command(command, *data)
        except SystemExit:
            break
        except InvalidSignatureException as exception:
            if not IS_PROD:
                continue
            print(str(exception))
        except InvalidCommandException:
            if not IS_PROD:
                print('Unknown command')
                continue
            print("I don't know this command.")
            possible_commands: list = difflib.get_close_matches(command, command_executor.command_list(), 1)
            if possible_commands:
                print(f'Did you mean "{possible_commands[0]}"?')


if __name__ == '__main__':
    run()
