DB = {}
TRANSACTION = []


def _set(params):
    DB[params[0]] = params[1]


def _get(params):
    print(DB[params[0]] if DB.get(params[0]) else 'NULL')


def _unset(params):
    if params[0] in DB:
        del DB[params[0]]


def _unknown(params):
    print(f'Unknown command: {params}')


def _counts(params):
    print(len([1 for _ in DB.values() if _ == params[0]]))


def _begin(*args):
    TRANSACTION.append([])


def _commit(*args):
    global TRANSACTION
    TRANSACTION = []


def _rollback(*args):
    if not TRANSACTION:
        return
    for action in reversed(TRANSACTION[-1]):
        pair = action.split()
        if 'None' in action:
            del DB[pair[0]]
        else:
            ACTIONS["set"](pair)
    del TRANSACTION[-1]


ACTIONS = {'set': _set, 'get': _get, 'unset': _unset, 'counts': _counts,
           'unknown': _unknown, 'begin': _begin, 'commit': _commit, 'rollback': _rollback}


def parse_command():
    line = input(">>>")
    if not line or line.lower() == 'end':
        return None, None
    line = line.lower()
    name, *parameters = line.split()
    if name not in ACTIONS:
        return 'unknown', name
    return name, parameters


def _run_action(name: str, parameters: str):
    if TRANSACTION:
        # Только сет и ансет что-то меняют в БД, их надо откатывать
        if 'set' in name:
            value = DB.get(parameters[0])
            TRANSACTION[-1].append(f'{parameters[0]} {value}')
    ACTIONS[name](parameters)


def run():
    while True:
        name, parameters = parse_command()
        if not name:
            break
        _run_action(name, parameters)


if __name__ == '__main__':
    run()
