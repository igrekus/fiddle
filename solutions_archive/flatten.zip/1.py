def out(list_out):
    f = []
    for i in list_out:
        if isinstance(i, list):
            for ii in i:
                f.append(ii)
        else:
            f.append(i)
    return f


def flatten(a_list, depth=None):
    if depth is None:
        while True in list(map(lambda x: isinstance(x, list), a_list)):
            a_list = out(a_list)
        return a_list
    else:
        for x in range(depth):
            a_list = out(a_list)
        return a_list

