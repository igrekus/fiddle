def flatten(a_list: list, depth: int = 0) -> list:
    if depth == 0:
        a1_list = flatten(a_list, 1)
        if a_list == a1_list:
            return a_list
        else:
            return flatten(a1_list)
    else:
        a1_list = []
        for i in a_list:
            if isinstance(i, int):
                a1_list.append(i)
            else:
                for j in i:
                    a1_list.append(j)
    if depth == 1:
        return a1_list
    else:
        return flatten(a1_list, depth - 1)
