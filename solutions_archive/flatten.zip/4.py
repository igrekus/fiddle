from typing import Generator, Any


def __extractor(a_list: list, depth: int) -> Generator[Any, None, None]:
    """
    Returns an unpacked list generator.

    :param a_list: List to unpacking.
    :param depth: Unpacking depth.
    :return: Generator
    """
    for item in a_list:
        if isinstance(item, list) and depth != 0:
            yield from __extractor(item, depth - 1 if depth > 0 else depth)
        else:
            yield item


def flatten(a_list: list, depth: int = 0) -> list:
    """
    Returns an unpacked list.

    :param a_list: List to unpacking.
    :param depth: Unpacking depth.
    :return: Flatted list
    """
    result = []
    for item in a_list:
        if isinstance(item, list):
            result.extend(__extractor(item, depth - 1))
        else:
            result.append(item)
    return result
