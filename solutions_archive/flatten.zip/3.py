def flatten(a_list: list, depth: int = 0) -> list:
    result = []
    [result.extend(item) if type(item) == list else result.append(item) for item in a_list]
    return result if a_list == result or depth == 1 else flatten(result, depth - 1)


if __name__ == '__main__':
    print(flatten([1, [2]]))
    print(flatten([1, [2, [3]]], depth=1))
    print([1, [[[2, [3, [[4, [5, [6]]]]]], [7, [8]]], [9]], 10])
    print(flatten([1, [[[2, [3, [[4, [5, [6]]]]]], [7, [8]]], [9]], 10], depth=1))
    print(flatten([1, [[[2, [3, [[4, [5, [6]]]]]], [7, [8]]], [9]], 10], depth=2))
    print(flatten([1, [[[2, [3, [[4, [5, [6]]]]]], [7, [8]]], [9]], 10], depth=3))
    print(flatten([1, [[[2, [3, [[4, [5, [6]]]]]], [7, [8]]], [9]], 10]))
    print(flatten([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]))
    print(flatten([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 1))
    print(flatten([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 4))
