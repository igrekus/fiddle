"""
Написать функцию def flatten(a_list:list, depth:int=0)->list  которая принимает на вход список, который может иметь
любую вложенность (список в списке), а также второй параметр - глубину распаковки. Функция должна вернуть список, где
вложенные элементы соответствующего уровня распакованы, то есть вложенное превращается в плоское. Если второй аргумент
не передан, то возвращает одномерный список, то есть все вложенные списки распакованы.

Примеры:
flatten([1, [2]) == [1, 2]
flatten([1, [2, [3]]], depth=1) == [1, 2, [3]]
Исключений не кидаем, предполагается что глубина всегда положительна (если указана), предполагаем что могут быть
только вложенные списки (не кортежи или другие контейнеры)
Импортировать ничего нельзя, сигнатуру функции не менять, решения кидать мне в личку в виде модуля пайтон,
все участники получат все варианты решений в следующую субботу!
"""


def flatten(a_list: list, depth: int = 0) -> list:
    def flat1(a):
        result = []
        for i in a:
            if isinstance(i, list):
                result.extend(i)
            else:
                result.append(i)

        return result

    flat2 = lambda *a: (_ for i in a for _ in (flat2(*i) if isinstance(i, list) else (i,)))

    if not depth:
        return list(flat2(a_list))
    else:
        result = []
        for i in a_list:
            d = 0
            if isinstance(i, list):
                while d < depth - 1:
                    d += 1
                    empty = all(isinstance(_, list) for _ in i)
                    i = flat1(i)
                    if empty:
                        break

                result.extend(i)
                continue

            result.append(i)

        return result


if __name__ == '__main__':
    print(flatten([1, [2, [3], [4, [5, [6], [[7], 8]]]]]))
    print(flatten([1, [2, [3], [4, [5, [6], [[7], 8]]]]], 0))
    print(flatten([1, [2, [3], [4, [5, [6], [[7], 8]]]]], 1))
    print(flatten([1, [2, [3], [4, [5, [6], [[7], 8]]]]], 2))
    print(flatten([1, [2, [3], [4, [5, [6], [[7], 8]]]]], 3))
    print(flatten([1, [2, [3], [4, [5, [6], [[7], 8]]]]], 4))
    print(flatten([1, [2, [3], [4, [5, [6], [[7], 8]]]]], 5))
