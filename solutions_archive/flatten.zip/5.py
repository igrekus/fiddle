def flatten(a_list: list, depth: int = 0) -> list:
    unpacked = False
    unpacked_list = []
    while not unpacked:
        for item in a_list:
            if type(item) == list and depth != 1:
                unpacked_list.extend(flatten(item, depth - 1))
            else:
                if type(item) == list:
                    unpacked_list.extend(item)
                else:
                    unpacked_list.append(item)
        unpacked = True
    return unpacked_list
