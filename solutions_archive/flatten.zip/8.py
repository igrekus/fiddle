def flatten(a_list: list, depth: int = 0) -> list:
    count = 0
    while True:
        result = []
        is_any_list = False
        for element in a_list:
            if type(element) is list:
                result += element
                is_any_list = True
            else:
                result.append(element)
        a_list = result
        count += 1
        if not is_any_list or (0 < depth == count):
            break
    return result
